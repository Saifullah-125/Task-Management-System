import java.io.*;
import java.util.HashMap;
import java.util.Map;

class UserAuthSystem {
    private Map<String, String> users;
    private Map<String, String> userEmails;
    private Map<String, Integer> loginAttempts;
    private static final String USER_FILE = "users.dat";
    private static final int MAX_ATTEMPTS = 3;

    public UserAuthSystem() {
        users = new HashMap<>();
        userEmails = new HashMap<>();
        loginAttempts = new HashMap<>();
        loadUsers();

        // If no users exist or load failed, create default users
        if (users.isEmpty()) {
            createDefaultUsers();
        }
    }

    private void createDefaultUsers() {
        users.put("admin", "admin123");
        userEmails.put("admin", "admin@taskscheduler.com");
        users.put("user1", "pass123");
        userEmails.put("user1", "user1@email.com");
        users.put("demo", "demo");
        userEmails.put("demo", "demo@example.com");
        saveUsers();
    }

    public boolean authenticate(String username, String password) {
        if (!users.containsKey(username)) {
            incrementAttempts(username);
            return false;
        }

        if (loginAttempts.containsKey(username) && loginAttempts.get(username) >= MAX_ATTEMPTS) {
            return false;
        }

        boolean authenticated = users.get(username).equals(password);
        if (authenticated) {
            loginAttempts.remove(username);
        } else {
            incrementAttempts(username);
        }
        return authenticated;
    }

    private void incrementAttempts(String username) {
        int attempts = loginAttempts.getOrDefault(username, 0) + 1;
        loginAttempts.put(username, attempts);
    }

    public boolean isAccountLocked(String username) {
        return loginAttempts.containsKey(username) && loginAttempts.get(username) >= MAX_ATTEMPTS;
    }

    public int getRemainingAttempts(String username) {
        int attempts = loginAttempts.getOrDefault(username, 0);
        return Math.max(0, MAX_ATTEMPTS - attempts);
    }

    public boolean resetPassword(String username, String email, String newPassword) {
        if (userEmails.containsKey(username) && userEmails.get(username).equals(email)) {
            users.put(username, newPassword);
            loginAttempts.remove(username);
            saveUsers();
            return true;
        }
        return false;
    }

    public boolean registerUser(String username, String password, String email) {
        if (users.containsKey(username)) { return false; }
        users.put(username, password);
        userEmails.put(username, email);
        saveUsers();
        return true;
    }

    @SuppressWarnings("unchecked")
    private void loadUsers() {
        File userFile = new File(USER_FILE);
        if (!userFile.exists()) {
            return; // File doesn't exist yet, will be created with default users
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(USER_FILE))) {
            Object loadedObject = ois.readObject();

            // Handle both old format (Map<String, String>) and new format (Map<String, String[]>)
            if (loadedObject instanceof Map) {
                Map<?, ?> loadedMap = (Map<?, ?>) loadedObject;

                // Check if it's the old format
                if (!loadedMap.isEmpty()) {
                    Object firstValue = loadedMap.values().iterator().next();

                    if (firstValue instanceof String) {
                        // Old format: Map<String, String>
                        users = (Map<String, String>) loadedObject;
                        // Create default emails for existing users
                        for (String username : users.keySet()) {
                            userEmails.put(username, username + "@example.com");
                        }
                    } else if (firstValue instanceof String[]) {
                        // New format: Map<String, String[]>
                        Map<String, String[]> userData = (Map<String, String[]>) loadedObject;
                        for (Map.Entry<String, String[]> entry : userData.entrySet()) {
                            users.put(entry.getKey(), entry.getValue()[0]);
                            userEmails.put(entry.getKey(), entry.getValue()[1]);
                        }
                    }
                }
            }
        } catch (FileNotFoundException e) {
            // File doesn't exist, will be created
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading users: " + e.getMessage());
            // If loading fails, use default users
            createDefaultUsers();
        } catch (ClassCastException e) {
            System.err.println("Data format error in user file. Creating fresh user data.");
            // If there's a cast exception, delete the corrupt file and create default users
            new File(USER_FILE).delete();
            createDefaultUsers();
        }
    }

    private void saveUsers() {
        Map<String, String[]> userData = new HashMap<>();
        for (String username : users.keySet()) {
            userData.put(username, new String[]{users.get(username), userEmails.get(username)});
        }
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(USER_FILE))) {
            oos.writeObject(userData);
        } catch (IOException e) {
            System.err.println("Error saving users: " + e.getMessage());
        }
    }
}
