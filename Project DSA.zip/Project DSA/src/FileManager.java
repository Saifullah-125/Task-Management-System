import java.io.*;
import java.util.Calendar;
import java.util.List;

// ==================== FILE MANAGER ====================
class FileManager {
    private static final String TASK_FILE = "tasks.dat";
    private static final String ACTIVITY_FILE = "activities.dat";
    private static final String COUNTER_FILE = "counter.dat";

    public static void saveData(TaskBST taskBST, ActivityCircularQueue activityLog, int taskIdCounter) {
        saveTasks(taskBST);
        // Activities are saved automatically by ActivityCircularQueue
        saveTaskCounter(taskIdCounter);
    }

    public static void loadData(TaskBST taskBST, TaskPriorityQueue priorityQueue, ActivityCircularQueue activityLog) {
        loadTasks(taskBST, priorityQueue);
        // Activities are loaded automatically by ActivityCircularQueue constructor
    }
    public static int loadTaskCounter() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(COUNTER_FILE))) {
            return (int) ois.readObject();
        } catch (FileNotFoundException e) { return 1; }
        catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading task counter: " + e.getMessage());
            return 1;
        }
    }

    private static void saveTasks(TaskBST taskBST) {
        List<Task> tasks = taskBST.inorderTraversal();
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(TASK_FILE))) {
            oos.writeObject(tasks);
        } catch (IOException e) {
            System.err.println("Error saving tasks: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private static void loadTasks(TaskBST taskBST, TaskPriorityQueue priorityQueue) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(TASK_FILE))) {
            List<Task> tasks = (List<Task>) ois.readObject();
            taskBST.clear(); priorityQueue.clear();
            for (Task task : tasks) {
                Calendar cal = Calendar.getInstance();
                if (task.startTime == null) { task.startTime = cal.getTime(); }
                if (task.endTime == null) { cal.add(Calendar.HOUR, 1); task.endTime = cal.getTime(); }
                taskBST.insert(task); priorityQueue.add(task);
            }
        } catch (FileNotFoundException e) { /* No saved tasks */ }
        catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading tasks: " + e.getMessage());
        }
    }

    private static void saveActivities(ActivityCircularQueue activityLog) {
        List<String> activities = activityLog.getActivities();
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ACTIVITY_FILE))) {
            oos.writeObject(activities);
        } catch (IOException e) {
            System.err.println("Error saving activities: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private static void loadActivities(ActivityCircularQueue activityLog) {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ACTIVITY_FILE))) {
            List<String> activities = (List<String>) ois.readObject();
            activityLog.clear();
            for (String activity : activities) { activityLog.enqueue(activity); }
        } catch (FileNotFoundException e) { /* No saved activities */ }
        catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading activities: " + e.getMessage());
        }
    }

    private static void saveTaskCounter(int taskIdCounter) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(COUNTER_FILE))) {
            oos.writeObject(taskIdCounter);
        } catch (IOException e) {
            System.err.println("Error saving task counter: " + e.getMessage());
        }
    }
}
