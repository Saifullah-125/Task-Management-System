import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

// ==================== TASK CLASS ====================
class Task implements Serializable {
    private static final long serialVersionUID = 1L;
    int id;
    String title;
    String description;
    int priority;
    String status;
    Date addedTime;
    Date startTime;
    Date endTime;

    public Task(int id, String title, String description, int priority, Date startTime, Date endTime) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = "Pending";
        this.addedTime = new Date();
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public Task(int id, String title, String description, int priority) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = "Pending";
        this.addedTime = new Date();
        Calendar cal = Calendar.getInstance();
        this.startTime = cal.getTime();
        cal.add(Calendar.HOUR, 1);
        this.endTime = cal.getTime();
    }

    public String getPriorityString() {
        switch(priority) {
            case 3: return "High";
            case 2: return "Medium";
            default: return "Low";
        }
    }

    public String getFormattedStartTime() {
        if (startTime == null) return "Not set";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
        return sdf.format(startTime);
    }

    public String getFormattedEndTime() {
        if (endTime == null) return "Not set";
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
        return sdf.format(endTime);
    }

    public String getTimeStatus() {
        if (startTime == null || endTime == null) return "No time set";
        Date now = new Date();
        if (endTime.before(now)) { return "Overdue"; }
        else if (startTime.after(now)) { return "Upcoming"; }
        else if (startTime.before(now) && endTime.after(now)) { return "Active"; }
        return "No time set";
    }
}
