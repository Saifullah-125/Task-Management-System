import java.util.ArrayList;
import java.util.List;

class TaskBST {
    private class Node {
        Task task;
        Node left, right;
        Node(Task task) { this.task = task; }
    }

    private Node root;

    public void insert(Task task) { root = insertRec(root, task); }
    private Node insertRec(Node root, Task task) {
        if (root == null) return new Node(task);
        if (task.id < root.task.id) { root.left = insertRec(root.left, task); }
        else if (task.id > root.task.id) { root.right = insertRec(root.right, task); }
        return root;
    }

    public Task search(int id) { return searchRec(root, id); }
    private Task searchRec(Node root, int id) {
        if (root == null || root.task.id == id) { return root != null ? root.task : null; }
        if (id < root.task.id) { return searchRec(root.left, id); }
        return searchRec(root.right, id);
    }

    public List<Task> inorderTraversal() {
        List<Task> tasks = new ArrayList<>();
        inorderRec(root, tasks);
        return tasks;
    }

    private void inorderRec(Node root, List<Task> tasks) {
        if (root != null) {
            inorderRec(root.left, tasks);
            tasks.add(root.task);
            inorderRec(root.right, tasks);
        }
    }

    public void delete(int id) { root = deleteRec(root, id); }
    private Node deleteRec(Node root, int id) {
        if (root == null) return null;
        if (id < root.task.id) { root.left = deleteRec(root.left, id); }
        else if (id > root.task.id) { root.right = deleteRec(root.right, id); }
        else {
            if (root.left == null) return root.right;
            if (root.right == null) return root.left;
            Node minNode = findMin(root.right);
            root.task = minNode.task;
            root.right = deleteRec(root.right, minNode.task.id);
        }
        return root;
    }

    private Node findMin(Node root) {
        while (root.left != null) { root = root.left; }
        return root;
    }

    public void clear() { root = null; }
    public int getMaxId() { return getMaxIdRec(root); }
    private int getMaxIdRec(Node root) {
        if (root == null) return 0;
        if (root.right == null) return root.task.id;
        return getMaxIdRec(root.right);
    }
}