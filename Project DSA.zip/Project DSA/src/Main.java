// user1 = pass123
// Email = user1@email.com

// demo = demo123
// email = demo@example.com

// admin = admin123
// Email = admin@taskscheduler.com

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}