import java.io.*;
import java.util.ArrayList;
import java.util.List;

class ActivityCircularQueue {
    private List<String> activities;
    private static final String ACTIVITY_FILE = "all_activities.dat";

    public ActivityCircularQueue() {
        activities = new ArrayList<>();
        loadAllActivities();
    }

    public void enqueue(String activity) {
        activities.add(activity);
        saveAllActivities();
    }

    public List<String> getActivities() {
        return new ArrayList<>(activities);
    }

    public void clear() {
        activities.clear();
        saveAllActivities();
    }

    private void saveAllActivities() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ACTIVITY_FILE))) {
            oos.writeObject(activities);
        } catch (IOException e) {
            System.err.println("Error saving all activities: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private void loadAllActivities() {
        File activityFile = new File(ACTIVITY_FILE);
        if (!activityFile.exists()) {
            return;
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ACTIVITY_FILE))) {
            activities = (List<String>) ois.readObject();
        } catch (FileNotFoundException e) {
            // File doesn't exist, will be created
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading all activities: " + e.getMessage());
            activities = new ArrayList<>();
        }
    }

    public int getActivityCount() {
        return activities.size();
    }
}
