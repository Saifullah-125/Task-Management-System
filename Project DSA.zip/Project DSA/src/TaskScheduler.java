import javax.swing.*;
import javax.swing.Timer;
import javax.swing.plaf.basic.BasicComboBoxUI;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer; // Add this line
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.concurrent.atomic.AtomicReference;
// ==================== MAIN APPLICATION ====================
public class TaskScheduler extends JFrame {
    private UserAuthSystem authSystem;
    private TaskPriorityQueue priorityQueue;
    private TaskBST taskBST;
    private ActivityCircularQueue activityLog;
    private String currentUser;
    private int taskIdCounter = 1;

    private CardLayout cardLayout;
    private JPanel mainPanel;

    public TaskScheduler() {
        authSystem = new UserAuthSystem();
        priorityQueue = new TaskPriorityQueue();
        taskBST = new TaskBST();
        activityLog = new ActivityCircularQueue(); // No capacity limit
        loadAllData();

        setTitle("Task Scheduler - DSA Project");
        setSize(1200, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) { saveAllData(); }
        });

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.add(createLoginPanel(), "LOGIN");
        mainPanel.add(createDashboardPanel(), "DASHBOARD");
        add(mainPanel);
        cardLayout.show(mainPanel, "LOGIN");
    }

    private void loadAllData() {
        FileManager.loadData(taskBST, priorityQueue, activityLog);
        taskIdCounter = FileManager.loadTaskCounter();
        int maxId = taskBST.getMaxId();
        if (maxId >= taskIdCounter) { taskIdCounter = maxId + 1; }
    }

    private void saveAllData() { FileManager.saveData(taskBST, activityLog, taskIdCounter); }

    // ==================== UPDATED LOGIN PANEL ====================
    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(45, 45, 60)); // Dark blue-gray background

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 20, 15, 20);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Main container for better centering
        JPanel loginContainer = new JPanel(new GridBagLayout());
        loginContainer.setBackground(new Color(60, 60, 80));
        loginContainer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(40, 40, 40, 40)
        ));

        GridBagConstraints containerGbc = new GridBagConstraints();
        containerGbc.insets = new Insets(20, 20, 20, 20);
        containerGbc.fill = GridBagConstraints.HORIZONTAL;

        // Title Label - Increased font size to 42
        JLabel titleLabel = new JLabel("TASK SCHEDULER");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 42));
        titleLabel.setForeground(new Color(255, 215, 0)); // Gold color
        containerGbc.gridx = 0; containerGbc.gridy = 0; containerGbc.gridwidth = 2;
        containerGbc.anchor = GridBagConstraints.CENTER;
        loginContainer.add(titleLabel, containerGbc);

        // Subtitle
        JLabel subtitleLabel = new JLabel("Secure Login System");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        subtitleLabel.setForeground(Color.LIGHT_GRAY);
        containerGbc.gridy = 1;
        containerGbc.gridwidth = 2;
        loginContainer.add(subtitleLabel, containerGbc);

        // Username Label
        JLabel userLabel = new JLabel("USERNAME");
        userLabel.setFont(new Font("Arial", Font.BOLD, 24));
        userLabel.setForeground(Color.WHITE);
        containerGbc.gridy = 2;
        containerGbc.gridwidth = 1;
        containerGbc.anchor = GridBagConstraints.WEST;
        loginContainer.add(userLabel, containerGbc);

        // Username Field - Styled input box
        JTextField usernameField = new JTextField(25);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 20));
        usernameField.setPreferredSize(new Dimension(400, 50));
        usernameField.setMinimumSize(new Dimension(400, 50));
        usernameField.setMaximumSize(new Dimension(400, 50));
        usernameField.setBackground(new Color(80, 80, 100));
        usernameField.setForeground(Color.WHITE);
        usernameField.setCaretColor(Color.WHITE);
        usernameField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        containerGbc.gridx = 1;
        loginContainer.add(usernameField, containerGbc);

        // Password Label
        JLabel passLabel = new JLabel("PASSWORD");
        passLabel.setFont(new Font("Arial", Font.BOLD, 24));
        passLabel.setForeground(Color.WHITE);
        containerGbc.gridx = 0; containerGbc.gridy = 3;
        loginContainer.add(passLabel, containerGbc);

        // Password Field - Styled input box
        JPasswordField passwordField = new JPasswordField(25);
        passwordField.setFont(new Font("Arial", Font.PLAIN, 20));
        passwordField.setPreferredSize(new Dimension(400, 50));
        passwordField.setMinimumSize(new Dimension(400, 50));
        passwordField.setMaximumSize(new Dimension(400, 50));
        passwordField.setBackground(new Color(80, 80, 100));
        passwordField.setForeground(Color.WHITE);
        passwordField.setCaretColor(Color.WHITE);
        passwordField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(10, 15, 10, 15)
        ));
        containerGbc.gridx = 1;
        loginContainer.add(passwordField, containerGbc);

        // Error Message Label (hidden initially)
        JLabel errorLabel = new JLabel(" ");
        errorLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        errorLabel.setForeground(new Color(255, 100, 100));
        containerGbc.gridx = 0; containerGbc.gridy = 4;
        containerGbc.gridwidth = 2;
        containerGbc.anchor = GridBagConstraints.CENTER;
        loginContainer.add(errorLabel, containerGbc);

        // Login Button - Large and styled
        JButton loginButton = new JButton("LOGIN");
        loginButton.setFont(new Font("Arial", Font.BOLD, 28));
        loginButton.setPreferredSize(new Dimension(300, 60));
        loginButton.setBackground(new Color(70, 130, 180)); // Steel blue
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        loginButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50, 110, 160), 3),
                BorderFactory.createEmptyBorder(10, 30, 10, 30)
        ));
        loginButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effect
        loginButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                loginButton.setBackground(new Color(60, 120, 170));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                loginButton.setBackground(new Color(70, 130, 180));
            }
        });

        containerGbc.gridy = 5;
        loginContainer.add(loginButton, containerGbc);

        // Forgot Password Link
        JButton forgotPasswordButton = new JButton("Forgot Password?");
        forgotPasswordButton.setFont(new Font("Arial", Font.PLAIN, 16));
        forgotPasswordButton.setForeground(new Color(100, 180, 255));
        forgotPasswordButton.setBackground(new Color(60, 60, 80));
        forgotPasswordButton.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        forgotPasswordButton.setFocusPainted(false);
        forgotPasswordButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        containerGbc.gridy = 6;
        loginContainer.add(forgotPasswordButton, containerGbc);

        // Login Action
        loginButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                errorLabel.setText("Please enter both username and password!");
                return;
            }

            // Check if account is locked
            if (authSystem.isAccountLocked(username)) {
                errorLabel.setText("Account locked! Too many failed attempts. Use 'Forgot Password' to reset.");
                return;
            }

            if (authSystem.authenticate(username, password)) {
                // Successful login - no message shown
                currentUser = username;
                activityLog.enqueue("User '" + username + "' logged in");
                cardLayout.show(mainPanel, "DASHBOARD");
                // Clear fields and error
                usernameField.setText("");
                passwordField.setText("");
                errorLabel.setText(" ");
            } else {
                int remainingAttempts = authSystem.getRemainingAttempts(username);
                errorLabel.setText("Incorrect username or password! Attempts remaining: " + remainingAttempts);

                if (remainingAttempts <= 0) {
                    errorLabel.setText("Account locked! Too many failed attempts. Use 'Forgot Password' to reset.");
                }

                // Clear password field
                passwordField.setText("");
            }
        });

        // Forgot Password Action
        forgotPasswordButton.addActionListener(e -> showForgotPasswordDialog());

        // Add enter key support
        passwordField.addActionListener(e -> loginButton.doClick());

        // Add login container to main panel
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(loginContainer, gbc);

        return panel;
    }

    // ==================== FORGOT PASSWORD DIALOG ====================
    private void showForgotPasswordDialog() {
        JDialog dialog = new JDialog(this, "Password Recovery", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new GridBagLayout());
        dialog.getContentPane().setBackground(new Color(60, 60, 80));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("🔑 Password Recovery");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        dialog.add(titleLabel, gbc);

        JLabel instructionLabel = new JLabel("<html><div style='text-align: center;'>Enter your username and email to reset your password</div></html>");
        instructionLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        instructionLabel.setForeground(Color.LIGHT_GRAY);
        gbc.gridy = 1;
        dialog.add(instructionLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 2; gbc.gridx = 0;
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Arial", Font.BOLD, 16));
        userLabel.setForeground(Color.WHITE);
        dialog.add(userLabel, gbc);

        gbc.gridx = 1;
        JTextField usernameField = new JTextField(20);
        usernameField.setFont(new Font("Arial", Font.PLAIN, 14));
        dialog.add(usernameField, gbc);

        gbc.gridy = 3; gbc.gridx = 0;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(new Font("Arial", Font.BOLD, 16));
        emailLabel.setForeground(Color.WHITE);
        dialog.add(emailLabel, gbc);

        gbc.gridx = 1;
        JTextField emailField = new JTextField(20);
        emailField.setFont(new Font("Arial", Font.PLAIN, 14));
        dialog.add(emailField, gbc);

        gbc.gridy = 4; gbc.gridx = 0;
        JLabel newPassLabel = new JLabel("New Password:");
        newPassLabel.setFont(new Font("Arial", Font.BOLD, 16));
        newPassLabel.setForeground(Color.WHITE);
        dialog.add(newPassLabel, gbc);

        gbc.gridx = 1;
        JPasswordField newPassField = new JPasswordField(20);
        newPassField.setFont(new Font("Arial", Font.PLAIN, 14));
        dialog.add(newPassField, gbc);

        JLabel resultLabel = new JLabel(" ");
        resultLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        resultLabel.setForeground(new Color(100, 255, 100));
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        dialog.add(resultLabel, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setBackground(new Color(60, 60, 80));

        JButton resetButton = new JButton("Reset Password");
        resetButton.setBackground(new Color(70, 130, 180));
        resetButton.setForeground(Color.WHITE);
        resetButton.setFocusPainted(false);

        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(120, 120, 120));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);

        resetButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String email = emailField.getText().trim();
            String newPassword = new String(newPassField.getPassword());

            if (username.isEmpty() || email.isEmpty() || newPassword.isEmpty()) {
                resultLabel.setForeground(new Color(255, 100, 100));
                resultLabel.setText("Please fill all fields!");
                return;
            }

            if (authSystem.resetPassword(username, email, newPassword)) {
                resultLabel.setForeground(new Color(100, 255, 100));
                resultLabel.setText("Password reset successful! You can now login.");
                new Timer(2000, ev -> dialog.dispose()).start();
            } else {
                resultLabel.setForeground(new Color(255, 100, 100));
                resultLabel.setText("Invalid username or email!");
            }
        });

        cancelButton.addActionListener(e -> dialog.dispose());

        buttonPanel.add(resetButton);
        buttonPanel.add(cancelButton);

        gbc.gridy = 6;
        dialog.add(buttonPanel, gbc);

        dialog.setVisible(true);
    }

    // ==================== DASHBOARD PANEL ====================
    private CardLayout dashboardCardLayout;
    private JPanel dashboardMainPanel;

    private JPanel createDashboardPanel() {
        // Create main panel with card layout for switching views
        dashboardCardLayout = new CardLayout();
        dashboardMainPanel = new JPanel(dashboardCardLayout);
        dashboardMainPanel.setBackground(new Color(45, 45, 60));

        // Add all panels to the card layout
        dashboardMainPanel.add(createMainDashboardView(), "MAIN_DASHBOARD");
        dashboardMainPanel.add(createProfileView(), "PROFILE");
        dashboardMainPanel.add(createStatusView(), "STATUS");
        dashboardMainPanel.add(createActivityLogView(), "ACTIVITY_LOG");
        dashboardMainPanel.add(createUpdateStatusView(), "UPDATE_STATUS");
        dashboardMainPanel.add(createAboutView(), "ABOUT");
        dashboardMainPanel.add(createInsertTaskPanel(), "INSERT_TASK");
        dashboardMainPanel.add(createDeleteTaskPanel(), "DELETE_TASK"); // Add this line

        // Show main dashboard initially
        dashboardCardLayout.show(dashboardMainPanel, "MAIN_DASHBOARD");

        return dashboardMainPanel;
    }


    private JPanel createMainDashboardView() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(45, 45, 60));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(60, 60, 80));
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));

        JLabel headerLabel = new JLabel("Task Scheduler Dashboard");
        headerLabel.setFont(new Font("Times New Roman", Font.BOLD, 50));
        headerLabel.setForeground(new Color(255, 215, 0));
        headerPanel.add(headerLabel, BorderLayout.CENTER);

        JPanel headerButtonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        headerButtonPanel.setOpaque(false);

        // Create the three-dot menu button
        JButton menuButton = new JButton("<html>⋮</html>");
        menuButton.setFont(new Font("Times New Roman", Font.BOLD, 32));
        menuButton.setBackground(new Color(60, 60, 80));
        menuButton.setForeground(new Color(255, 215, 0));
        menuButton.setBorder(BorderFactory.createEmptyBorder(20, 25, 20, 25));
        menuButton.setFocusPainted(false);
        menuButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        menuButton.setContentAreaFilled(false);
        menuButton.setPreferredSize(new Dimension(80, 80));

        // Add hover effect
        menuButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                menuButton.setForeground(new Color(255, 235, 150));
                menuButton.setBackground(new Color(70, 130, 180));
                menuButton.setContentAreaFilled(true);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                menuButton.setForeground(new Color(255, 215, 0));
                menuButton.setBackground(new Color(60, 60, 80));
                menuButton.setContentAreaFilled(false);
            }
        });

        // Create popup menu
        JPopupMenu popupMenu = new JPopupMenu() {
            @Override
            public Dimension getPreferredSize() {
                return new Dimension(300, 450);
            }
        };

        popupMenu.setBackground(new Color(60, 60, 80));
        popupMenu.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(5, 2, 5, 2)
        ));

        // Create menu items
        JMenuItem profileMenuItem = createThemeMenuItem("  Profile", 20);
        JMenuItem saveMenuItem = createThemeMenuItem("  Save Data", 20);
        JMenuItem statusMenuItem = createThemeMenuItem("  Status", 20);
        JMenuItem activityMenuItem = createThemeMenuItem("  Activity Log", 20);
        JMenuItem updateStatusMenuItem = createThemeMenuItem("  Update Status", 20);
        JMenuItem aboutMenuItem = createThemeMenuItem("   About", 20);
        JMenuItem logoutMenuItem = createThemeMenuItem("  Logout", 20);

        // Add menu items
        popupMenu.add(profileMenuItem);
        popupMenu.addSeparator();
        popupMenu.add(saveMenuItem);
        popupMenu.add(statusMenuItem);
        popupMenu.add(activityMenuItem);
        popupMenu.add(updateStatusMenuItem);
        popupMenu.addSeparator();
        popupMenu.add(aboutMenuItem);
        popupMenu.addSeparator();
        popupMenu.add(logoutMenuItem);

        // Menu item actions
        profileMenuItem.addActionListener(e -> {
            popupMenu.setVisible(false);
            dashboardCardLayout.show(dashboardMainPanel, "PROFILE");
        });

        saveMenuItem.addActionListener(e -> {
            saveAllData();
            JOptionPane.showMessageDialog(this, "Data saved successfully!");
            popupMenu.setVisible(false);
        });

        statusMenuItem.addActionListener(e -> {
            popupMenu.setVisible(false);
            dashboardCardLayout.show(dashboardMainPanel, "STATUS");
        });

        activityMenuItem.addActionListener(e -> {
            popupMenu.setVisible(false);
            dashboardCardLayout.show(dashboardMainPanel, "ACTIVITY_LOG");
        });

        updateStatusMenuItem.addActionListener(e -> {
            popupMenu.setVisible(false);
            dashboardCardLayout.show(dashboardMainPanel, "UPDATE_STATUS");
        });

        aboutMenuItem.addActionListener(e -> {
            popupMenu.setVisible(false);
            dashboardCardLayout.show(dashboardMainPanel, "ABOUT");
        });

        logoutMenuItem.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Are you sure you want to logout?",
                    "Confirm Logout",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                saveAllData();
                activityLog.enqueue("User '" + currentUser + "' logged out");
                currentUser = null;
                popupMenu.setVisible(false);
                cardLayout.show(mainPanel, "LOGIN");
            }
        });

        // Show popup menu
        menuButton.addActionListener(e -> {
            int x = menuButton.getWidth() - popupMenu.getPreferredSize().width;
            popupMenu.show(menuButton, x, menuButton.getHeight());
        });

        // Add menu button to header
        headerButtonPanel.add(menuButton);
        headerPanel.add(headerButtonPanel, BorderLayout.EAST);
        panel.add(headerPanel, BorderLayout.NORTH);

        // CENTER PANEL - Vertical column of buttons
        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(new Color(45, 45, 60));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(20, 20, 20, 20);
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Create buttons
        JButton insertButton = createThemeButton("  Insert Task", new Color(70, 130, 180));
        JButton deleteButton = createThemeButton("  Delete Task", new Color(180, 70, 70));
        JButton todoButton = createThemeButton(" To-Do List", new Color(70, 130, 180));

        // Add buttons vertically
        gbc.gridy = 0;
        centerPanel.add(insertButton, gbc);

        gbc.gridy = 1;
        centerPanel.add(deleteButton, gbc);

        gbc.gridy = 2;
        centerPanel.add(todoButton, gbc);

        // Make buttons wider
        Dimension buttonSize = new Dimension(400, 80);
        insertButton.setPreferredSize(buttonSize);
        deleteButton.setPreferredSize(buttonSize);
        todoButton.setPreferredSize(buttonSize);

        panel.add(centerPanel, BorderLayout.CENTER);

        // Welcome message panel
//        JPanel welcomePanel = new JPanel(new BorderLayout());
//        welcomePanel.setBackground(new Color(60, 60, 80));
//        welcomePanel.setBorder(BorderFactory.createCompoundBorder(
//                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
//                BorderFactory.createEmptyBorder(15, 20, 15, 20)
//        ));
//
//        JLabel welcomeLabel = new JLabel("Welcome, " + (currentUser != null ? currentUser : "User") + "! 👋");
//        welcomeLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
//        welcomeLabel.setForeground(new Color(255, 215, 0));
//
//        JLabel instructionLabel = new JLabel("Click on ⋮ for menu options");
//        instructionLabel.setFont(new Font("Times New Roman", Font.PLAIN, 16));
//        instructionLabel.setForeground(Color.LIGHT_GRAY);
//
//        welcomePanel.add(welcomeLabel, BorderLayout.WEST);
//        welcomePanel.add(instructionLabel, BorderLayout.EAST);
//
//        panel.add(welcomePanel, BorderLayout.SOUTH);

        // Add action listeners for main buttons
        // In createMainDashboardView() method, update the insert button action:
        insertButton.addActionListener(e -> {
            dashboardCardLayout.show(dashboardMainPanel, "INSERT_TASK");
        });
        // In createMainDashboardView() method, find the delete button action and update it:
        deleteButton.addActionListener(e -> showDeleteTaskDialog());

        todoButton.addActionListener(e -> showToDoList());

        // In createMainDashboardView() method, update the statusMenuItem action:
        statusMenuItem.addActionListener(e -> {
            popupMenu.setVisible(false);
            // Remove old status view and add fresh one
            dashboardMainPanel.removeAll();
            dashboardMainPanel.add(createMainDashboardView(), "MAIN_DASHBOARD");
            dashboardMainPanel.add(createProfileView(), "PROFILE");
            dashboardMainPanel.add(createStatusView(), "STATUS"); // Fresh status view
            dashboardMainPanel.add(createActivityLogView(), "ACTIVITY_LOG");
            dashboardMainPanel.add(createUpdateStatusView(), "UPDATE_STATUS");
            dashboardMainPanel.add(createAboutView(), "ABOUT");
            dashboardCardLayout.show(dashboardMainPanel, "STATUS");
        });

        return panel;
    }

    private JButton createThemeButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Times New Roman", Font.BOLD, 22));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(
                        Math.max(bgColor.getRed() - 30, 0),
                        Math.max(bgColor.getGreen() - 30, 0),
                        Math.max(bgColor.getBlue() - 30, 0)
                ), 2),
                BorderFactory.createEmptyBorder(20, 40, 20, 40)
        ));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effect
        button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(
                        Math.min(bgColor.getRed() + 20, 255),
                        Math.min(bgColor.getGreen() + 20, 255),
                        Math.min(bgColor.getBlue() + 20, 255)
                ));
                button.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(
                                Math.max(bgColor.getRed() - 20, 0),
                                Math.max(bgColor.getGreen() - 20, 0),
                                Math.max(bgColor.getBlue() - 20, 0)
                        ), 3),
                        BorderFactory.createEmptyBorder(20, 40, 20, 40)
                ));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                button.setBackground(bgColor);
                button.setBorder(BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(new Color(
                                Math.max(bgColor.getRed() - 30, 0),
                                Math.max(bgColor.getGreen() - 30, 0),
                                Math.max(bgColor.getBlue() - 30, 0)
                        ), 2),
                        BorderFactory.createEmptyBorder(20, 40, 20, 40)
                ));
            }
        });

        return button;
    }

    private JMenuItem createThemeMenuItem(String text, int fontSize) {
        JMenuItem menuItem = new JMenuItem(text) {
            @Override
            public Dimension getPreferredSize() {
                Dimension size = super.getPreferredSize();
                return new Dimension(size.width + 50, size.height + 25);
            }
        };

        menuItem.setFont(new Font("Times New Roman", Font.PLAIN, fontSize));
        menuItem.setBackground(new Color(80, 80, 100)); // Match login input field color
        menuItem.setForeground(Color.WHITE);
        menuItem.setOpaque(true);
        menuItem.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 1), // Match login border
                BorderFactory.createEmptyBorder(15, 25, 15, 25)
        ));

        // Add hover effect for menu items
        menuItem.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                menuItem.setBackground(new Color(100, 100, 120)); // Lighter on hover
                menuItem.setForeground(new Color(255, 215, 0)); // Gold text on hover
            }

            @Override
            public void mouseExited(MouseEvent e) {
                menuItem.setBackground(new Color(80, 80, 100)); // Back to input field color
                menuItem.setForeground(Color.WHITE);
            }

            @Override
            public void mousePressed(MouseEvent e) {
                menuItem.setBackground(new Color(70, 130, 180)); // Steel blue when pressed
            }
        });

        return menuItem;
    }
    // PROFILE VIEW
    private JPanel createProfileView() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(45, 45, 60));

        // Header with back button
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(60, 60, 80));
        headerPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(15, 20, 15, 20)
        ));


        // Profile Content Panel
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(new Color(45, 45, 60));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Profile icon
        JLabel profileIcon = new JLabel(" User Profile", JLabel.CENTER);
        profileIcon.setFont(new Font("Arial", Font.PLAIN, 80));
        profileIcon.setForeground(new Color(255, 215, 0));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        contentPanel.add(profileIcon, gbc);

        // Username
        gbc.gridwidth = 1;
        gbc.gridy = 1; gbc.gridx = 0;
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        userLabel.setForeground(Color.WHITE);
        contentPanel.add(userLabel, gbc);

        gbc.gridx = 1;
        JTextField userField = new JTextField(currentUser != null ? currentUser : "Guest");
        userField.setEditable(false);
        userField.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        userField.setBackground(new Color(80, 80, 100));
        userField.setForeground(Color.WHITE);
        userField.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140)));
        userField.setPreferredSize(new Dimension(300, 40));
        contentPanel.add(userField, gbc);

        // Login Time
        gbc.gridy = 2; gbc.gridx = 0;
        JLabel loginLabel = new JLabel("Login Time:");
        loginLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        loginLabel.setForeground(Color.WHITE);
        contentPanel.add(loginLabel, gbc);

        gbc.gridx = 1;
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
        JTextField timeField = new JTextField(sdf.format(new Date()));
        timeField.setEditable(false);
        timeField.setFont(new Font("Times New Roman", Font.PLAIN, 20));
        timeField.setBackground(new Color(80, 80, 100));
        timeField.setForeground(Color.WHITE);
        timeField.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140)));
        timeField.setPreferredSize(new Dimension(300, 40));
        contentPanel.add(timeField, gbc);

        // Statistics
        List<Task> tasks = taskBST.inorderTraversal();
        int totalTasks = tasks.size();
        int completed = 0;
        int highPriority = 0;

        for (Task task : tasks) {
            if (task.status.equals("Completed")) completed++;
            if (task.priority == 3) highPriority++;
        }

        // Total Tasks
        gbc.gridy = 3; gbc.gridx = 0;
        JLabel totalLabel = new JLabel("Total Tasks:");
        totalLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        totalLabel.setForeground(Color.WHITE);
        contentPanel.add(totalLabel, gbc);

        gbc.gridx = 1;
        JLabel totalValue = new JLabel(String.valueOf(totalTasks));
        totalValue.setFont(new Font("Times New Roman", Font.BOLD, 20));
        totalValue.setForeground(new Color(255, 215, 0));
        contentPanel.add(totalValue, gbc);

        // Completed Tasks
        gbc.gridy = 4; gbc.gridx = 0;
        JLabel completedLabel = new JLabel("Completed:");
        completedLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        completedLabel.setForeground(Color.WHITE);
        contentPanel.add(completedLabel, gbc);

        gbc.gridx = 1;
        JLabel completedValue = new JLabel(String.valueOf(completed));
        completedValue.setFont(new Font("Times New Roman", Font.BOLD, 20));
        completedValue.setForeground(new Color(76, 175, 80));
        contentPanel.add(completedValue, gbc);

        // High Priority Tasks
        gbc.gridy = 5; gbc.gridx = 0;
        JLabel highLabel = new JLabel("High Priority:");
        highLabel.setFont(new Font("Times New Roman", Font.BOLD, 20));
        highLabel.setForeground(Color.WHITE);
        contentPanel.add(highLabel, gbc);

        gbc.gridx = 1;
        JLabel highValue = new JLabel(String.valueOf(highPriority));
        highValue.setFont(new Font("Times New Roman", Font.BOLD, 20));
        highValue.setForeground(new Color(244, 67, 54));
        contentPanel.add(highValue, gbc);

        panel.add(contentPanel, BorderLayout.CENTER);
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(new Color(45, 45, 60));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 40, 20));

        JButton backButton = createBackButton();
        backButton.addActionListener(e -> dashboardCardLayout.show(dashboardMainPanel, "MAIN_DASHBOARD"));
        bottomPanel.add(backButton);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    // STATUS VIEW - COMPLETE INLINE VERSION (no separate method)
    private JPanel createStatusView() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(45, 45, 60));

        // Create main container with BorderLayout
        JPanel mainContainer = new JPanel(new BorderLayout());
        mainContainer.setBackground(new Color(45, 45, 60));
        mainContainer.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel titleLabel = new JLabel("  Task Status Dashboard", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 50));
        titleLabel.setForeground(new Color(255, 215, 0));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));

        mainContainer.add(titleLabel, BorderLayout.NORTH);

        // CENTER: Create table panel with current data
        List<Task> currentTasks = taskBST.inorderTraversal(); // Get current tasks

        if (currentTasks.isEmpty()) {
            JLabel noTasksLabel = new JLabel("No tasks available!", JLabel.CENTER);
            noTasksLabel.setFont(new Font("Times New Roman", Font.BOLD, 28));
            noTasksLabel.setForeground(Color.WHITE);
            noTasksLabel.setBorder(BorderFactory.createEmptyBorder(50, 0, 50, 0));
            mainContainer.add(noTasksLabel, BorderLayout.CENTER);
        } else {
            // Create the table panel directly here
            JPanel tablePanel = new JPanel(new BorderLayout());
            tablePanel.setBackground(new Color(45, 45, 60));

            // Table title with current task count
            JLabel tableTitle = new JLabel("  All Tasks - " + currentTasks.size() + " tasks found", JLabel.CENTER);
            tableTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
            tableTitle.setForeground(new Color(255, 215, 0));
            tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
            tablePanel.add(tableTitle, BorderLayout.NORTH);

            // Create the table with CURRENT task data
            String[] columns = {"ID", "Task Name", "Priority", "Start Time", "End Time", "Status"};
            DefaultTableModel model = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            // Add CURRENT tasks to table with their CURRENT status
            for (Task task : currentTasks) {
                model.addRow(new Object[]{
                        task.id,
                        task.title,
                        task.getPriorityString(),
                        task.getFormattedStartTime(),
                        task.getFormattedEndTime(),
                        task.status  // This shows the CURRENT status
                });
            }

            // Create table
            JTable taskTable = new JTable(model);

            // Basic table styling
            taskTable.setFont(new Font("Times New Roman", Font.PLAIN, 18));
            taskTable.setRowHeight(35); // Taller rows for better visibility
            taskTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 20));
            taskTable.getTableHeader().setBackground(new Color(80, 80, 100));
            taskTable.getTableHeader().setForeground(new Color(255, 215, 0)); // Gold header text
            taskTable.setGridColor(new Color(100, 100, 140));
            taskTable.setShowGrid(true);
            taskTable.setSelectionBackground(new Color(70, 130, 180));
            taskTable.setSelectionForeground(Color.WHITE);

            // Set column widths
            taskTable.getColumnModel().getColumn(0).setPreferredWidth(60);  // ID
            taskTable.getColumnModel().getColumn(1).setPreferredWidth(250); // Task Name
            taskTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Priority
            taskTable.getColumnModel().getColumn(3).setPreferredWidth(180); // Start Time
            taskTable.getColumnModel().getColumn(4).setPreferredWidth(180); // End Time
            taskTable.getColumnModel().getColumn(5).setPreferredWidth(120); // Status

            // Custom cell renderer for status-based coloring
            taskTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value,
                                                               boolean isSelected, boolean hasFocus, int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                    // Default: White text on dark background
                    c.setBackground(new Color(60, 60, 80));
                    c.setForeground(Color.WHITE);

                    // Only color the status column (column 5)
                    if (column == 5 && value != null) {
                        String status = value.toString();

                        if (status.equals("Completed")) {
                            c.setBackground(new Color(0, 100, 0)); // Dark Green background
                            c.setForeground(Color.WHITE); // White text
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (status.equals("In Progress")) {
                            c.setBackground(Color.YELLOW); // Yellow background
                            c.setForeground(Color.BLACK); // White text
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (status.equals("Pending")) {
                            c.setBackground(Color.RED); // Red background
                            c.setForeground(Color.WHITE); // White text
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        }
                    }

                    // Color priority column
                    if (column == 2 && value != null) {
                        String priority = value.toString();
                        if (priority.equals("High")) {
                            c.setForeground(Color.CYAN); // Light Red
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (priority.equals("Medium")) {
                            c.setForeground(Color.BLACK); // Light Orange
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (priority.equals("Low")) {
                            c.setForeground(new Color(100, 255, 100)); // Light Green
                        }
                    }

                    // Color ID column
                    if (column == 0) {
                        c.setForeground(new Color(255, 215, 0)); // Gold
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    }

                    // Center align all cells
                    ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);

                    return c;
                }
            });

            // Create scroll pane
            JScrollPane scrollPane = new JScrollPane(taskTable);
            scrollPane.setPreferredSize(new Dimension(900, 350));
            scrollPane.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                    BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));
            scrollPane.getViewport().setBackground(new Color(60, 60, 80));

            // Add scroll pane to panel
            tablePanel.add(scrollPane, BorderLayout.CENTER);

            mainContainer.add(tablePanel, BorderLayout.CENTER);
        }

        panel.add(mainContainer, BorderLayout.CENTER);

        // BOTTOM: Back Button only
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(new Color(45, 45, 60));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 40, 20));

        JButton backButton = createBackButton();
        backButton.addActionListener(e -> dashboardCardLayout.show(dashboardMainPanel, "MAIN_DASHBOARD"));
        bottomPanel.add(backButton);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    // Helper method to create task table panel with real-time data
//    private JPanel createTaskTablePanel(List<Task> tasks) {
//        JPanel tablePanel = new JPanel(new BorderLayout());
//        tablePanel.setBackground(new Color(45, 45, 60));
//
//        // Table title with current task count
//        JLabel tableTitle = new JLabel("📋 All Tasks - " + tasks.size() + " tasks found", JLabel.CENTER);
//        tableTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
//        tableTitle.setForeground(new Color(255, 215, 0));
//        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
//        tablePanel.add(tableTitle, BorderLayout.NORTH);
//
//        // Create the table with CURRENT task data
//        String[] columns = {"ID", "Task Name", "Priority", "Start Time", "End Time", "Status"};
//        DefaultTableModel model = new DefaultTableModel(columns, 0) {
//            @Override
//            public boolean isCellEditable(int row, int column) {
//                return false;
//            }
//        };
//
//        // Add CURRENT tasks to table with their CURRENT status
//        for (Task task : tasks) {
//            model.addRow(new Object[]{
//                    task.id,
//                    task.title,
//                    task.getPriorityString(),
//                    task.getFormattedStartTime(),
//                    task.getFormattedEndTime(),
//                    task.status  // This shows the CURRENT status
//            });
//        }
//
//        // Create table
//        JTable taskTable = new JTable(model);
//
//        // Basic table styling
//        taskTable.setFont(new Font("Times New Roman", Font.PLAIN, 14));
//        taskTable.setRowHeight(35); // Taller rows for better visibility
//        taskTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 16));
//        taskTable.getTableHeader().setBackground(new Color(80, 80, 100));
//        taskTable.getTableHeader().setForeground(new Color(255, 215, 0)); // Gold header text
//        taskTable.setGridColor(new Color(100, 100, 140));
//        taskTable.setShowGrid(true);
//        taskTable.setSelectionBackground(new Color(70, 130, 180));
//        taskTable.setSelectionForeground(Color.WHITE);
//
//        // Set column widths
//        taskTable.getColumnModel().getColumn(0).setPreferredWidth(60);  // ID
//        taskTable.getColumnModel().getColumn(1).setPreferredWidth(250); // Task Name
//        taskTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Priority
//        taskTable.getColumnModel().getColumn(3).setPreferredWidth(180); // Start Time
//        taskTable.getColumnModel().getColumn(4).setPreferredWidth(180); // End Time
//        taskTable.getColumnModel().getColumn(5).setPreferredWidth(120); // Status
//
//        // Custom cell renderer for status-based coloring
//        taskTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
//            @Override
//            public Component getTableCellRendererComponent(JTable table, Object value,
//                                                           boolean isSelected, boolean hasFocus, int row, int column) {
//                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
//
//                // Default: White text on dark background
//                c.setBackground(new Color(60, 60, 80));
//                c.setForeground(Color.WHITE);
//
//                // Only color the status column (column 5)
//                if (column == 5 && value != null) {
//                    String status = value.toString();
//
//                    if (status.equals("Completed")) {
//                        c.setBackground(new Color(0, 100, 0)); // Dark Green background
//                        c.setForeground(Color.WHITE); // White text
//                        c.setFont(c.getFont().deriveFont(Font.BOLD));
//                    } else if (status.equals("In Progress")) {
//                        c.setBackground(new Color(200, 150, 0)); // Yellow background
//                        c.setForeground(Color.WHITE); // White text
//                        c.setFont(c.getFont().deriveFont(Font.BOLD));
//                    } else if (status.equals("Pending")) {
//                        c.setBackground(new Color(150, 0, 0)); // Red background
//                        c.setForeground(Color.WHITE); // White text
//                        c.setFont(c.getFont().deriveFont(Font.BOLD));
//                    }
//                }
//
//                // Color priority column
//                if (column == 2 && value != null) {
//                    String priority = value.toString();
//                    if (priority.equals("High")) {
//                        c.setForeground(new Color(255, 100, 100)); // Light Red
//                        c.setFont(c.getFont().deriveFont(Font.BOLD));
//                    } else if (priority.equals("Medium")) {
//                        c.setForeground(new Color(255, 200, 100)); // Light Orange
//                        c.setFont(c.getFont().deriveFont(Font.BOLD));
//                    } else if (priority.equals("Low")) {
//                        c.setForeground(new Color(100, 255, 100)); // Light Green
//                    }
//                }
//
//                // Color ID column
//                if (column == 0) {
//                    c.setForeground(new Color(255, 215, 0)); // Gold
//                    c.setFont(c.getFont().deriveFont(Font.BOLD));
//                }
//
//                // Center align all cells
//                ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
//
//                return c;
//            }
//        });
//
//        // Create scroll pane
//        JScrollPane scrollPane = new JScrollPane(taskTable);
//        scrollPane.setPreferredSize(new Dimension(900, 350));
//        scrollPane.setBorder(BorderFactory.createCompoundBorder(
//                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
//                BorderFactory.createEmptyBorder(5, 5, 5, 5)
//        ));
//        scrollPane.getViewport().setBackground(new Color(60, 60, 80));
//
//        // Add scroll pane to panel
//        tablePanel.add(scrollPane, BorderLayout.CENTER);
//
//        return tablePanel;
//    }

    // Helper method to create statistics panel
    private JPanel createStatisticsPanel() {
        JPanel statsPanel = new JPanel(new GridBagLayout());
        statsPanel.setBackground(new Color(45, 45, 60));
        statsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Title
        JLabel titleLabel = new JLabel("  Task Status ", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 50)); // Smaller font
        titleLabel.setForeground(new Color(255, 215, 0));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        statsPanel.add(titleLabel, gbc);

        List<Task> tasks = taskBST.inorderTraversal();

        if (tasks.isEmpty()) {
            JLabel noTasksLabel = new JLabel("No tasks available!", JLabel.CENTER);
            noTasksLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
            noTasksLabel.setForeground(Color.WHITE);
            gbc.gridy = 1;
            statsPanel.add(noTasksLabel, gbc);
        } else {
            // Calculate statistics
            int pending = 0, inProgress = 0, completed = 0;
            int high = 0, medium = 0, low = 0;
            int overdue = 0, active = 0, upcoming = 0;

            for (Task task : tasks) {
                switch (task.status) {
                    case "Pending": pending++; break;
                    case "In Progress": inProgress++; break;
                    case "Completed": completed++; break;
                }

                switch (task.priority) {
                    case 3: high++; break;
                    case 2: medium++; break;
                    case 1: low++; break;
                }

                if (task.endTime != null && task.endTime.before(new Date()) && !task.status.equals("Completed")) {
                    overdue++;
                } else if (task.startTime != null && task.endTime != null &&
                        task.startTime.before(new Date()) && task.endTime.after(new Date())) {
                    active++;
                } else if (task.startTime != null && task.startTime.after(new Date())) {
                    upcoming++;
                }
            }

            // Display statistics in 2 columns
            String[] leftLabels = {"Total Tasks:", "Pending:", "In Progress:", "Completed:", "High Priority:"};
            String[] leftValues = {
                    String.valueOf(tasks.size()),
                    String.valueOf(pending),
                    String.valueOf(inProgress),
                    String.valueOf(completed),
                    String.valueOf(high)
            };
            Color[] leftColors = {
                    new Color(255, 215, 0),
                    Color.WHITE,
                    Color.WHITE,
                    new Color(76, 175, 80),
                    new Color(244, 67, 54)
            };

            String[] rightLabels = {"Medium Priority:", "Low Priority:", "Overdue:", "Active:", "Upcoming:"};
            String[] rightValues = {
                    String.valueOf(medium),
                    String.valueOf(low),
                    String.valueOf(overdue),
                    String.valueOf(active),
                    String.valueOf(upcoming)
            };
            Color[] rightColors = {
                    new Color(255, 152, 0),
                    new Color(33, 150, 243),
                    new Color(244, 67, 54),
                    new Color(76, 175, 80),
                    new Color(255, 152, 0)
            };

            // Left column
            for (int i = 0; i < leftLabels.length; i++) {
                gbc.gridwidth = 1;
                gbc.gridy = i + 1;
                gbc.gridx = 0;

                JLabel statLabel = new JLabel(leftLabels[i]);
                statLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
                statLabel.setForeground(Color.WHITE);
                statsPanel.add(statLabel, gbc);

                gbc.gridx = 1;
                JLabel statValue = new JLabel(leftValues[i]);
                statValue.setFont(new Font("Times New Roman", Font.BOLD, 16));
                statValue.setForeground(leftColors[i]);
                statsPanel.add(statValue, gbc);
            }

            // Right column
            gbc.gridx = 2;
            gbc.gridy = 1;

            for (int i = 0; i < rightLabels.length; i++) {
                gbc.gridy = i + 1;
                gbc.gridx = 2;

                JLabel statLabel = new JLabel(rightLabels[i]);
                statLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
                statLabel.setForeground(Color.WHITE);
                statsPanel.add(statLabel, gbc);

                gbc.gridx = 3;
                JLabel statValue = new JLabel(rightValues[i]);
                statValue.setFont(new Font("Times New Roman", Font.BOLD, 16));
                statValue.setForeground(rightColors[i]);
                statsPanel.add(statValue, gbc);
            }
        }

        return statsPanel;
    }

    // Helper method to create task table panel
    private JPanel createTaskTablePanel(List<Task> tasks) {
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(new Color(45, 45, 60));

        // Table title
        JLabel tableTitle = new JLabel("  All Tasks (" + tasks.size() + " total)", JLabel.CENTER);
        tableTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
        tableTitle.setForeground(new Color(255, 215, 0));
        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        tablePanel.add(tableTitle, BorderLayout.NORTH);

        // Create the table
        String[] columns = {"ID", "Task Name", "Priority", "Start Time", "End Time", "Status"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Add tasks to table
        for (Task task : tasks) {
            model.addRow(new Object[]{
                    task.id,
                    task.title,
                    task.getPriorityString(),
                    task.getFormattedStartTime(),
                    task.getFormattedEndTime(),
                    task.status
            });
        }

        // Create table with custom rendering
        JTable taskTable = new JTable(model);

        // Basic table styling
        taskTable.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        taskTable.setRowHeight(30);
        taskTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 16));
        taskTable.getTableHeader().setBackground(new Color(80, 80, 100));
        taskTable.getTableHeader().setForeground(new Color(255, 215, 0));
        taskTable.setGridColor(new Color(100, 100, 140));
        taskTable.setShowGrid(true);

        // Set column widths
        taskTable.getColumnModel().getColumn(0).setPreferredWidth(50);  // ID
        taskTable.getColumnModel().getColumn(1).setPreferredWidth(250); // Task Name
        taskTable.getColumnModel().getColumn(2).setPreferredWidth(80);  // Priority
        taskTable.getColumnModel().getColumn(3).setPreferredWidth(150); // Start Time
        taskTable.getColumnModel().getColumn(4).setPreferredWidth(150); // End Time
        taskTable.getColumnModel().getColumn(5).setPreferredWidth(100); // Status

        // Custom cell renderer for color coding
        taskTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                // Get the task for this row
                Task task = tasks.get(row);

                // Default colors
                Color bgColor = new Color(60, 60, 80);
                Color fgColor = Color.WHITE;

                // Color coding based on task status
                if (task.status.equals("Completed")) {
                    bgColor = Color.GRAY; // Green
                    fgColor = Color.WHITE;
                } else if (task.status.equals("In Progress")) {
                    bgColor = Color.gray; // Orange/Brown
                    fgColor = Color.white;
                } else if (task.status.equals("Pending")) {
                    bgColor = Color.GRAY; // Red
                    fgColor = Color.WHITE;
                }

                // Highlight overdue tasks
                if (task.endTime != null && task.endTime.before(new Date()) && !task.status.equals("Completed")) {
                    bgColor = Color.GRAY; // Dark Red
                    fgColor = Color.WHITE;
                }

                // Apply colors
                c.setBackground(bgColor);
                c.setForeground(fgColor);

                // Center align all cells
                ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);

                // Make ID and Priority bold
                if (column == 0 || column == 2) {
                    c.setFont(c.getFont().deriveFont(Font.BOLD));
                }

                return c;
            }
        });

        // Create scroll pane
        JScrollPane scrollPane = new JScrollPane(taskTable);
        scrollPane.setPreferredSize(new Dimension(900, 300));
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140), 2));

        // Add scroll pane to panel
        tablePanel.add(scrollPane, BorderLayout.CENTER);

//        // Add legend at bottom
//        JPanel legendPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
//        legendPanel.setBackground(new Color(45, 45, 60));

//        // Create legend items
//        String[] legendTexts = {"🟢 Completed", "🟡 In Progress", "🔴 Pending", "⏰ Overdue"};
//        Color[] legendBgColors = {
//                new Color(50, 100, 50),
//                new Color(100, 80, 40),
//                new Color(100, 50, 50),
//                new Color(120, 40, 40)
//        };
//        Color[] legendFgColors = {
//                new Color(220, 255, 220),
//                new Color(255, 240, 200),
//                new Color(255, 220, 220),
//                new Color(255, 200, 200)
//        };
//
//        for (int i = 0; i < legendTexts.length; i++) {
//            JLabel legendItem = new JLabel(legendTexts[i]);
//            legendItem.setFont(new Font("Times New Roman", Font.BOLD, 14));
//            legendItem.setForeground(legendFgColors[i]);
//            legendItem.setBackground(legendBgColors[i]);
//            legendItem.setOpaque(true);
//            legendItem.setBorder(BorderFactory.createCompoundBorder(
//                    BorderFactory.createLineBorder(new Color(150, 150, 180)),
//                    BorderFactory.createEmptyBorder(5, 10, 5, 10)
//            ));
//            legendPanel.add(legendItem);
//        }

//        tablePanel.add(legendPanel, BorderLayout.SOUTH);

        return tablePanel;
    }

    // ACTIVITY LOG VIEW - ADMIN CONTROLS FOR HISTORY MANAGEMENT
    private JPanel createActivityLogView() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(45, 45, 60));

        // Create main container with BorderLayout
        JPanel mainContainer = new JPanel(new BorderLayout());
        mainContainer.setBackground(new Color(45, 45, 60));
        mainContainer.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel titleLabel = new JLabel(" Complete Activity History", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 80));
        titleLabel.setForeground(new Color(255, 215, 0));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        mainContainer.add(titleLabel, BorderLayout.NORTH);

        // CENTER: Create activity table panel
        JPanel tablePanel = createActivityTablePanel();
        mainContainer.add(tablePanel, BorderLayout.CENTER);

        panel.add(mainContainer, BorderLayout.CENTER);

        // BOTTOM: Button panel with conditional admin controls
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0));
        bottomPanel.setBackground(new Color(45, 45, 60));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 40, 20));

        // Back button (available to all users)
        JButton backButton = createBackButton();
        backButton.addActionListener(e -> dashboardCardLayout.show(dashboardMainPanel, "MAIN_DASHBOARD"));
        bottomPanel.add(backButton);

        // Refresh button (available to all users)
        JButton refreshButton = new JButton("🔄 Refresh");
        refreshButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
        refreshButton.setBackground(new Color(70, 130, 180));
        refreshButton.setForeground(Color.WHITE);
        refreshButton.setFocusPainted(false);
        refreshButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50, 110, 160), 2),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        refreshButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        refreshButton.addActionListener(e -> {
            mainContainer.remove(tablePanel);
            JPanel newTablePanel = createActivityTablePanel();
            mainContainer.add(newTablePanel, BorderLayout.CENTER);
            mainContainer.revalidate();
            mainContainer.repaint();
        });
        bottomPanel.add(refreshButton);

        // Check if current user is admin
        boolean isAdmin = currentUser != null && currentUser.equalsIgnoreCase("admin");

        if (isAdmin) {
            // Admin-only buttons

            // Export button
            JButton exportButton = new JButton("📥 Export History");
            exportButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
            exportButton.setBackground(new Color(76, 175, 80));
            exportButton.setForeground(Color.WHITE);
            exportButton.setFocusPainted(false);
            exportButton.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(56, 155, 70), 2),
                    BorderFactory.createEmptyBorder(10, 20, 10, 20)
            ));
            exportButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

            exportButton.addActionListener(e -> exportActivityHistory());
            bottomPanel.add(exportButton);

            // Clear History button (admin only)
            JButton clearButton = new JButton("🗑️ Clear History");
            clearButton.setFont(new Font("Times New Roman", Font.BOLD, 18));
            clearButton.setBackground(new Color(180, 70, 70));
            clearButton.setForeground(Color.WHITE);
            clearButton.setFocusPainted(false);
            clearButton.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(150, 50, 50), 2),
                    BorderFactory.createEmptyBorder(10, 20, 10, 20)
            ));
            clearButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

            clearButton.addActionListener(e -> {
                int confirm = JOptionPane.showConfirmDialog(this,
                        "⚠️ ADMIN ACTION ⚠️\n" +
                                "Are you sure you want to clear ALL activity history?\n" +
                                "This action cannot be undone and will remove all user activity records.",
                        "Confirm Clear History - ADMIN ONLY",
                        JOptionPane.YES_NO_OPTION,
                        JOptionPane.WARNING_MESSAGE);

                if (confirm == JOptionPane.YES_OPTION) {
                    activityLog.clear();
                    JOptionPane.showMessageDialog(this,
                            "Activity history cleared successfully!\n" +
                                    "All activity records have been removed.",
                            "History Cleared",
                            JOptionPane.INFORMATION_MESSAGE);
                    // Refresh the view
                    dashboardCardLayout.show(dashboardMainPanel, "ACTIVITY_LOG");
                }
            });
            bottomPanel.add(clearButton);

            // Admin indicator
            JLabel adminLabel = new JLabel("👑 ADMIN MODE");
            adminLabel.setFont(new Font("Times New Roman", Font.BOLD, 16));
            adminLabel.setForeground(new Color(255, 215, 0));
            adminLabel.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));
            bottomPanel.add(adminLabel);
        } else {
            // Non-admin user message
            JLabel userMessage = new JLabel("📜 View Only Mode - Contact admin for history management");
            userMessage.setFont(new Font("Times New Roman", Font.PLAIN, 14));
            userMessage.setForeground(Color.LIGHT_GRAY);
            userMessage.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 0));
            bottomPanel.add(userMessage);
        }

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    // Helper method to create the activity table panel
    private JPanel createActivityTablePanel() {
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(new Color(45, 45, 60));

        List<String> activities = activityLog.getActivities();

        if (activities.isEmpty()) {
            JLabel noActivitiesLabel = new JLabel("No activity history available!", JLabel.CENTER);
            noActivitiesLabel.setFont(new Font("Times New Roman", Font.BOLD, 28));
            noActivitiesLabel.setForeground(Color.WHITE);
            noActivitiesLabel.setBorder(BorderFactory.createEmptyBorder(50, 0, 50, 0));
            tablePanel.add(noActivitiesLabel, BorderLayout.CENTER);
        } else {
            // Table title with activity count and user info
            String titleText;
            boolean isAdmin = currentUser != null && currentUser.equalsIgnoreCase("admin");

            if (isAdmin) {
                titleText = "  All Activities - Total: " + activities.size() + " (Admin View)";
            } else {
                titleText = "  All Activities - Total: " + activities.size() + " (View Only)";
            }

            JLabel tableTitle = new JLabel(titleText, JLabel.CENTER);
            tableTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
            tableTitle.setForeground(new Color(255, 215, 0));
            tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
            tablePanel.add(tableTitle, BorderLayout.NORTH);

            // Create the table with activity data
            String[] columns = {"S.No", "Activity Type", "User", "Description", "Timestamp"};
            DefaultTableModel model = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            };

            // Process activities and extract information
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
            int serialNumber = 1;

            // Show activities from oldest to newest
            for (String activity : activities) {
                String activityType = categorizeActivity(activity);
                String username = extractUsername(activity);
                String description = activity;
                String timestamp = sdf.format(new Date());

                model.addRow(new Object[]{
                        serialNumber++,
                        activityType,
                        username,
                        description,
                        timestamp
                });
            }

            // Create table
            JTable activityTable = new JTable(model);

            // Basic table styling
            activityTable.setFont(new Font("Times New Roman", Font.PLAIN, 14));
            activityTable.setRowHeight(30);
            activityTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 16));
            activityTable.getTableHeader().setBackground(new Color(80, 80, 100));
            activityTable.getTableHeader().setForeground(new Color(255, 215, 0));
            activityTable.setGridColor(new Color(100, 100, 140));
            activityTable.setShowGrid(true);
            activityTable.setSelectionBackground(new Color(70, 130, 180));
            activityTable.setSelectionForeground(Color.WHITE);

            // Set column widths
            activityTable.getColumnModel().getColumn(0).setPreferredWidth(60);   // S.No
            activityTable.getColumnModel().getColumn(1).setPreferredWidth(120);  // Activity Type
            activityTable.getColumnModel().getColumn(2).setPreferredWidth(100);  // User
            activityTable.getColumnModel().getColumn(3).setPreferredWidth(600);  // Description
            activityTable.getColumnModel().getColumn(4).setPreferredWidth(150);  // Timestamp

            // Custom cell renderer for activity-based coloring
            activityTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value,
                                                               boolean isSelected, boolean hasFocus,
                                                               int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value,
                            isSelected, hasFocus, row, column);

                    // Default: White text on dark background
                    c.setBackground(new Color(60, 60, 80));
                    c.setForeground(Color.WHITE);

                    // Get activity type for this row
                    String activityType = (String) table.getValueAt(row, 1);

                    // Color coding based on activity type
                    if (activityType != null) {
                        switch (activityType) {
                            case "Login":
                                c.setBackground(new Color(40, 80, 120)); // Blue for login
                                c.setForeground(new Color(180, 220, 255));
                                break;
                            case "Logout":
                                c.setBackground(new Color(120, 40, 40)); // Red for logout
                                c.setForeground(new Color(255, 180, 180));
                                break;
                            case "Task Added":
                                c.setBackground(new Color(40, 120, 40)); // Green for task added
                                c.setForeground(new Color(180, 255, 180));
                                break;
                            case "Task Deleted":
                                c.setBackground(new Color(120, 80, 40)); // Orange for task deleted
                                c.setForeground(new Color(255, 220, 180));
                                break;
                            case "Status Updated":
                                c.setBackground(new Color(120, 40, 120)); // Purple for status update
                                c.setForeground(new Color(255, 180, 255));
                                break;
                            case "Data Saved":
                                c.setBackground(new Color(40, 120, 120)); // Teal for data saved
                                c.setForeground(new Color(180, 255, 255));
                                break;
                            case "General":
                                c.setBackground(new Color(80, 80, 100)); // Gray for general
                                c.setForeground(new Color(220, 220, 220));
                                break;
                        }
                    }

                    // Color serial number column
                    if (column == 0) {
                        c.setForeground(new Color(255, 215, 0));
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    }

                    // Highlight admin activities
                    String username = (String) table.getValueAt(row, 2);
                    if (username.equalsIgnoreCase("admin")) {
                        c.setBackground(new Color(80, 60, 120)); // Purple background for admin
                        c.setForeground(new Color(255, 255, 180)); // Light yellow text for admin
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    }

                    // Center align S.No and Timestamp columns
                    if (column == 0 || column == 4) {
                        ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
                    } else {
                        ((JLabel) c).setHorizontalAlignment(SwingConstants.LEFT);
                    }

                    return c;
                }
            });

            // Create scroll pane
            JScrollPane scrollPane = new JScrollPane(activityTable);
            scrollPane.setPreferredSize(new Dimension(1100, 500));
            scrollPane.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                    BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));
            scrollPane.getViewport().setBackground(new Color(60, 60, 80));

            // Add scroll pane to panel
            tablePanel.add(scrollPane, BorderLayout.CENTER);
        }

        return tablePanel;
    }

    // Helper method to export activity history (admin only)
    private void exportActivityHistory() {
        if (!currentUser.equalsIgnoreCase("admin")) {
            JOptionPane.showMessageDialog(this,
                    "Access Denied!\nOnly administrators can export activity history.",
                    "Admin Access Required",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Export Activity History");
        fileChooser.setSelectedFile(new File("activity_history_" +
                new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date()) + ".txt"));

        int userSelection = fileChooser.showSaveDialog(this);

        if (userSelection == JFileChooser.APPROVE_OPTION) {
            File fileToSave = fileChooser.getSelectedFile();

            try (PrintWriter writer = new PrintWriter(new FileWriter(fileToSave))) {
                List<String> activities = activityLog.getActivities();
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

                writer.println("=".repeat(80));
                writer.println("ACTIVITY HISTORY EXPORT");
                writer.println("Generated: " + sdf.format(new Date()));
                writer.println("Generated by: " + currentUser + " (ADMIN)");
                writer.println("Total Activities: " + activities.size());
                writer.println("=".repeat(80));
                writer.println();

                int serialNumber = 1;
                for (String activity : activities) {
                    writer.println(String.format("%4d. %s", serialNumber++, activity));
                }

                writer.println();
                writer.println("=".repeat(80));
                writer.println("END OF ACTIVITY HISTORY");
                writer.println("=".repeat(80));

                JOptionPane.showMessageDialog(this,
                        "Activity history exported successfully!\n" +
                                "File saved to: " + fileToSave.getAbsolutePath(),
                        "Export Successful",
                        JOptionPane.INFORMATION_MESSAGE);

            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                        "Error exporting activity history:\n" + e.getMessage(),
                        "Export Failed",
                        JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    // Helper method to extract username from activity message
    private String extractUsername(String activity) {
        // Pattern 1: "User 'username' logged in"
        if (activity.contains("User '") && activity.contains("' logged")) {
            int start = activity.indexOf("User '") + 6;
            int end = activity.indexOf("'", start);
            if (start < end) {
                return activity.substring(start, end);
            }
        }

        // Pattern 2: "User 'username' logged out"
        if (activity.contains("User '") && activity.contains("' logged out")) {
            int start = activity.indexOf("User '") + 6;
            int end = activity.indexOf("'", start);
            if (start < end) {
                return activity.substring(start, end);
            }
        }

        // If no username found, return "System"
        return "System";
    }

    // Helper method to categorize activities
    private String categorizeActivity(String activity) {
        activity = activity.toLowerCase();

        if (activity.contains("logged in")) {
            return "Login";
        } else if (activity.contains("logged out")) {
            return "Logout";
        } else if (activity.contains("task added")) {
            return "Task Added";
        } else if (activity.contains("task deleted")) {
            return "Task Deleted";
        } else if (activity.contains("status updated") || activity.contains("→")) {
            return "Status Updated";
        } else if (activity.contains("data saved") || activity.contains("saved successfully")) {
            return "Data Saved";
        } else {
            return "General";
        }
    }
    // UPDATE STATUS VIEW - SIMPLIFIED WITH SINGLE SELECTION
    private JPanel createUpdateStatusView() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(45, 45, 60));

        // Create main container with BorderLayout
        JPanel mainContainer = new JPanel(new BorderLayout());
        mainContainer.setBackground(new Color(45, 45, 60));
        mainContainer.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel titleLabel = new JLabel(" Update Task Status", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 80));
        titleLabel.setForeground(new Color(255, 215, 0));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        mainContainer.add(titleLabel, BorderLayout.NORTH);

        // Store tasks as a field to access them in listeners
        final List<Task>[] tasksHolder = new List[]{taskBST.inorderTraversal()};

        if (tasksHolder[0].isEmpty()) {
            JLabel noTasksLabel = new JLabel("No tasks available to update!", JLabel.CENTER);
            noTasksLabel.setFont(new Font("Times New Roman", Font.BOLD, 28));
            noTasksLabel.setForeground(Color.WHITE);
            noTasksLabel.setBorder(BorderFactory.createEmptyBorder(50, 0, 50, 0));
            mainContainer.add(noTasksLabel, BorderLayout.CENTER);
        } else {
            // Create the task table panel
            JPanel tablePanel = new JPanel(new BorderLayout());
            tablePanel.setBackground(new Color(45, 45, 60));

            // Table title
            JLabel tableTitle = new JLabel("  Select a task to update its status (Click on any task)", JLabel.CENTER);
            tableTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
            tableTitle.setForeground(new Color(255, 215, 0));
            tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
            tablePanel.add(tableTitle, BorderLayout.NORTH);

            // Create the table with task data
            String[] columns = {"ID", "Task Name", "Current Status", "Priority", "Start Time", "End Time"};
            DefaultTableModel model = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // No cells are editable
                }
            };

            // Add tasks to table
            for (Task task : tasksHolder[0]) {
                model.addRow(new Object[]{
                        task.id,
                        task.title,
                        task.status,
                        task.getPriorityString(),
                        task.getFormattedStartTime(),
                        task.getFormattedEndTime()
                });
            }

            // Create table with single selection
            JTable taskTable = new JTable(model);
            taskTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            // Store the table reference for later updates
            final JTable[] tableHolder = new JTable[]{taskTable};

            // Basic table styling
            taskTable.setFont(new Font("Times New Roman", Font.PLAIN, 18));
            taskTable.setRowHeight(35);
            taskTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 20));
            taskTable.getTableHeader().setBackground(new Color(80, 80, 100));
            taskTable.getTableHeader().setForeground(new Color(255, 215, 0));
            taskTable.setGridColor(new Color(100, 100, 140));
            taskTable.setShowGrid(true);
            taskTable.setSelectionBackground(new Color(70, 130, 180));
            taskTable.setSelectionForeground(Color.WHITE);

            // Set column widths
            taskTable.getColumnModel().getColumn(0).setPreferredWidth(60);   // ID
            taskTable.getColumnModel().getColumn(1).setPreferredWidth(300);  // Task Name
            taskTable.getColumnModel().getColumn(2).setPreferredWidth(120);  // Current Status
            taskTable.getColumnModel().getColumn(3).setPreferredWidth(100);  // Priority
            taskTable.getColumnModel().getColumn(4).setPreferredWidth(180);  // Start Time
            taskTable.getColumnModel().getColumn(5).setPreferredWidth(180);  // End Time

            // Custom cell renderer for color coding
            taskTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value,
                                                               boolean isSelected, boolean hasFocus,
                                                               int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value,
                            isSelected, hasFocus, row, column);

                    // Default: White text on dark background
                    c.setBackground(new Color(60, 60, 80));
                    c.setForeground(Color.WHITE);

                    // If row is selected, use selection colors
                    if (isSelected) {
                        return c;
                    }

                    // Get task for this row
                    Task task = tasksHolder[0].get(row);

                    // Color coding based on current status (column 2)
                    if (column == 2 && value != null) {
                        String status = value.toString();
                        if (status.equals("Completed")) {
                            c.setBackground(new Color(0, 100, 0)); // Dark Green
                            c.setForeground(Color.WHITE);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (status.equals("In Progress")) {
                            c.setBackground(new Color(200, 150, 0)); // Orange/Yellow
                            c.setForeground(Color.WHITE);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (status.equals("Pending")) {
                            c.setBackground(new Color(150, 0, 0)); // Dark Red
                            c.setForeground(Color.WHITE);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        }
                    }

                    // Color priority column
                    if (column == 3 && value != null) {
                        String priority = value.toString();
                        if (priority.equals("High")) {
                            c.setForeground(Color.RED);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (priority.equals("Medium")) {
                            c.setForeground(Color.ORANGE);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (priority.equals("Low")) {
                            c.setForeground(Color.GREEN);
                        }
                    }

                    // Color ID column
                    if (column == 0) {
                        c.setForeground(new Color(255, 215, 0)); // Gold
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    }

                    // Color task name column
                    if (column == 1) {
                        c.setForeground(new Color(200, 220, 255)); // Light blue
                    }

                    // Center align ID and Status columns
                    if (column == 0 || column == 2 || column == 3) {
                        ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
                    } else {
                        ((JLabel) c).setHorizontalAlignment(SwingConstants.LEFT);
                    }

                    return c;
                }
            });

            // Create scroll pane
            JScrollPane scrollPane = new JScrollPane(taskTable);
            scrollPane.setPreferredSize(new Dimension(1100, 400));
            scrollPane.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                    BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));
            scrollPane.getViewport().setBackground(new Color(60, 60, 80));

            // Add scroll pane to panel
            tablePanel.add(scrollPane, BorderLayout.CENTER);

            mainContainer.add(tablePanel, BorderLayout.CENTER);
        }

        panel.add(mainContainer, BorderLayout.CENTER);

        // BOTTOM: Back and Update buttons
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
        bottomPanel.setBackground(new Color(45, 45, 60));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 40, 20));

        // Back button
        JButton backButton = createBackButton();
        backButton.addActionListener(e -> dashboardCardLayout.show(dashboardMainPanel, "MAIN_DASHBOARD"));
        bottomPanel.add(backButton);

        // Update button (only shown if there are tasks)
        if (!tasksHolder[0].isEmpty()) {
            JButton updateButton = new JButton("🔄 Update Status");
            updateButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
            updateButton.setBackground(new Color(76, 175, 80));
            updateButton.setForeground(Color.WHITE);
            updateButton.setFocusPainted(false);
            updateButton.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(56, 155, 70), 2),
                    BorderFactory.createEmptyBorder(10, 20, 10, 20)
            ));
            updateButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

            // Add hover effect for update button
            updateButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    updateButton.setBackground(new Color(66, 165, 70));
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    updateButton.setBackground(new Color(76, 175, 80));
                }
            });

            updateButton.addActionListener(e -> {
                // Find the task table
                JTable taskTable = findTaskTable(mainContainer);
                if (taskTable == null) return;

                int selectedRow = taskTable.getSelectedRow();

                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(this,
                            "Please select a task to update!\n\n" +
                                    "Click on any task row to select it.",
                            "No Task Selected",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Task selectedTask = tasksHolder[0].get(selectedRow);
                showStatusSelectionDialog(selectedTask, taskTable, selectedRow);
            });

            bottomPanel.add(updateButton);
        }

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    // Method to show status selection dialog
    private void showStatusSelectionDialog(Task task, JTable taskTable, int selectedRow) {
        JDialog statusDialog = new JDialog(this, "Select New Status", true);
        statusDialog.setSize(400, 250);
        statusDialog.setLocationRelativeTo(this);
        statusDialog.setLayout(new BorderLayout());
        statusDialog.getContentPane().setBackground(new Color(60, 60, 80));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(80, 80, 100));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel headerLabel = new JLabel("Update Task Status");
        headerLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
        headerLabel.setForeground(new Color(255, 215, 0));
        headerPanel.add(headerLabel, BorderLayout.CENTER);

        JLabel taskLabel = new JLabel("Task: " + task.title);
        taskLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14));
        taskLabel.setForeground(Color.LIGHT_GRAY);
        headerPanel.add(taskLabel, BorderLayout.SOUTH);

        statusDialog.add(headerPanel, BorderLayout.NORTH);

        // Status selection panel
        JPanel statusPanel = new JPanel(new GridLayout(3, 1, 10, 10));
        statusPanel.setBackground(new Color(60, 60, 80));
        statusPanel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));

        // Create simple status buttons
        JButton pendingButton = new JButton("Pending");
        JButton inProgressButton = new JButton("In Progress");
        JButton completedButton = new JButton("Completed");

        // Style buttons simply
        Font buttonFont = new Font("Times New Roman", Font.BOLD, 18);
        Color buttonBg = new Color(80, 80, 100);
        Color buttonFg = Color.WHITE;

        pendingButton.setFont(buttonFont);
        pendingButton.setBackground(buttonBg);
        pendingButton.setForeground(buttonFg);
        pendingButton.setFocusPainted(false);
        pendingButton.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140), 2));

        inProgressButton.setFont(buttonFont);
        inProgressButton.setBackground(buttonBg);
        inProgressButton.setForeground(buttonFg);
        inProgressButton.setFocusPainted(false);
        inProgressButton.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140), 2));

        completedButton.setFont(buttonFont);
        completedButton.setBackground(buttonBg);
        completedButton.setForeground(buttonFg);
        completedButton.setFocusPainted(false);
        completedButton.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140), 2));

        // Add hover effect
        MouseAdapter hoverAdapter = new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                ((JButton) e.getSource()).setBackground(new Color(100, 100, 120));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                ((JButton) e.getSource()).setBackground(buttonBg);
            }
        };

        pendingButton.addMouseListener(hoverAdapter);
        inProgressButton.addMouseListener(hoverAdapter);
        completedButton.addMouseListener(hoverAdapter);

        // Add action listeners - update immediately without confirmation
        pendingButton.addActionListener(e -> {
            updateTaskStatusImmediately(task, "Pending", taskTable, selectedRow);
            statusDialog.dispose();
        });

        inProgressButton.addActionListener(e -> {
            updateTaskStatusImmediately(task, "In Progress", taskTable, selectedRow);
            statusDialog.dispose();
        });

        completedButton.addActionListener(e -> {
            updateTaskStatusImmediately(task, "Completed", taskTable, selectedRow);
            statusDialog.dispose();
        });

        statusPanel.add(pendingButton);
        statusPanel.add(inProgressButton);
        statusPanel.add(completedButton);

        statusDialog.add(statusPanel, BorderLayout.CENTER);

        statusDialog.setVisible(true);
    }

    // Method to update task status immediately without confirmation or message
    private void updateTaskStatusImmediately(Task task, String newStatus, JTable taskTable, int selectedRow) {
        String oldStatus = task.status;

        if (oldStatus.equals(newStatus)) {
            return; // No change needed
        }

        // Update task status
        task.status = newStatus;

        // Update priority queue
        priorityQueue.remove(task);
        priorityQueue.add(task);

        // Update the table immediately
        taskTable.setValueAt(newStatus, selectedRow, 2);

        // Force table repaint to show updated colors
        taskTable.repaint();

        // Log the activity
        activityLog.enqueue("Task status updated: " + task.title + " (" + oldStatus + " → " + newStatus + ")");

        // No confirmation or message shown - update happens silently
    }

    // Helper method to find the task table in the container
    private JTable findTaskTable(Container container) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof JTable) {
                return (JTable) comp;
            } else if (comp instanceof Container) {
                JTable found = findTaskTable((Container) comp);
                if (found != null) return found;
            }
        }
        return null;
    }

    // ABOUT VIEW
    private JPanel createAboutView() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(45, 45, 60));

        // Content Panel
        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(new Color(45, 45, 60));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 15, 15, 15);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Title
        JLabel titleLabel = new JLabel(" About Task Scheduler", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 80));
        titleLabel.setForeground(new Color(255, 215, 0));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        contentPanel.add(titleLabel, gbc);

        // About content in scrollable panel
        String aboutText =
                "<html><div style='color:white; font-size:18px; font-family:Times New Roman; line-height:1.6; text-align:center;'>" +
                        "📋 <b>Task Scheduler - DSA Project</b><br><br>" +
                        "<b>Version:</b> 1.4<br><br>" +
                        "<b>Data Structures Implemented:</b><br>" +
                        "• Priority Queue - High priority tasks first<br>" +
                        "• Binary Search Tree - Task organization by ID<br>" +
                        "• Circular Queue - Activity logging (last 10)<br>" +
                        "• HashMap - User authentication system<br><br>" +
                        "<b>Features:</b><br>" +
                        "✓ Secure login authentication<br>" +
                        "✓ Priority-based task scheduling<br>" +
                        "✓ Task management (Insert, Delete, View)<br>" +
                        "✓ Real-time status tracking<br>" +
                        "✓ Activity history logging<br>" +
                        "✓ File persistence - Data saved automatically<br>" +
                        "✓ Enhanced calendar date picker<br>" +
                        "✓ Simplified time picker with AM/PM<br>" +
                        "✓ Task status management (Pending/In Progress/Completed)<br>" +
                        "✓ Window maximization/minimization<br>" +
                        "✓ 12-hour time format with AM/PM<br><br>" +
                        "<b>Developed as a DSA course project</b><br>" +
                        "© 2024 Task Scheduler Team" +
                        "</div></html>";

        JLabel aboutLabel = new JLabel(aboutText);
        aboutLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // Put about content in a panel with fixed size
        JPanel aboutContentPanel = new JPanel(new BorderLayout());
        aboutContentPanel.setBackground(new Color(80, 80, 100));
        aboutContentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        aboutContentPanel.add(aboutLabel, BorderLayout.CENTER);

        JScrollPane scrollPane = new JScrollPane(aboutContentPanel);
        scrollPane.setPreferredSize(new Dimension(600, 300));
        scrollPane.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140)));

        gbc.gridy = 1;
        gbc.gridwidth = 2;
        contentPanel.add(scrollPane, gbc);

        panel.add(contentPanel, BorderLayout.CENTER);

        // Back button panel at bottom center
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(new Color(45, 45, 60));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 40, 20));

        JButton backButton = createBackButton();
        backButton.addActionListener(e -> dashboardCardLayout.show(dashboardMainPanel, "MAIN_DASHBOARD"));
        bottomPanel.add(backButton);

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }
    // Helper method to create back button
    private JButton createBackButton() {
        JButton backButton = new JButton(" Back ");
        backButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
        backButton.setBackground(new Color(70, 130, 180));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50, 110, 160), 2),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        backButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                backButton.setBackground(new Color(60, 120, 170));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                backButton.setBackground(new Color(70, 130, 180));
            }
        });

        return backButton;
    }

    // Helper method to create radio buttons with theme
    private JRadioButton createThemeRadioButton(String text) {
        JRadioButton radioButton = new JRadioButton(text);
        radioButton.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        radioButton.setBackground(new Color(80, 80, 100));
        radioButton.setForeground(Color.WHITE);
        radioButton.setFocusPainted(false);
        return radioButton;
    }
    private void showQuickStatsDialog() {
        List<Task> tasks = taskBST.inorderTraversal();
        int totalTasks = tasks.size();
        int completed = 0, pending = 0, inProgress = 0;

        for (Task task : tasks) {
            if (task.status.equals("Completed")) completed++;
            else if (task.status.equals("Pending")) pending++;
            else if (task.status.equals("In Progress")) inProgress++;
        }

        String stats = String.format(
                "📊 Quick Statistics\n\n" +
                        "Total Tasks: %d\n\n" +
                        "Status Breakdown:\n" +
                        " • Completed: %d (%.1f%%)\n" +
                        " • Pending: %d (%.1f%%)\n" +
                        " • In Progress: %d (%.1f%%)\n\n" +
                        "Tasks Created Today: %d",
                totalTasks,
                completed, totalTasks > 0 ? (completed * 100.0 / totalTasks) : 0,
                pending, totalTasks > 0 ? (pending * 100.0 / totalTasks) : 0,
                inProgress, totalTasks > 0 ? (inProgress * 100.0 / totalTasks) : 0,
                tasks.stream().filter(t -> t.addedTime != null &&
                        new SimpleDateFormat("dd/MM/yyyy").format(t.addedTime).equals(
                                new SimpleDateFormat("dd/MM/yyyy").format(new Date()))).count()
        );

        JOptionPane.showMessageDialog(this, stats, "Quick Statistics", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAnalyticsDialog() {
        List<Task> tasks = taskBST.inorderTraversal();

        if (tasks.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks available for analytics!");
            return;
        }

        JDialog dialog = new JDialog(this, "Task Analytics", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        dialog.getContentPane().setBackground(new Color(60, 60, 80));
        dialog.setLayout(new BorderLayout(10, 10));

        JPanel contentPanel = new JPanel(new GridBagLayout());
        contentPanel.setBackground(new Color(60, 60, 80));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titleLabel = new JLabel("📈 Task Analytics");
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 24));
        titleLabel.setForeground(new Color(255, 215, 0));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        contentPanel.add(titleLabel, gbc);

        // Calculate statistics
        int total = tasks.size();
        int high = 0, medium = 0, low = 0;
        int completed = 0, pending = 0, inProgress = 0;

        for (Task task : tasks) {
            if (task.priority == 3) high++;
            else if (task.priority == 2) medium++;
            else low++;

            if (task.status.equals("Completed")) completed++;
            else if (task.status.equals("Pending")) pending++;
            else if (task.status.equals("In Progress")) inProgress++;
        }

        String analytics = String.format(
                "<html><div style='color:white; font-size:16px; font-family:Times New Roman;'>" +
                        "📊 <b>Overall Statistics</b><br>" +
                        "Total Tasks: %d<br><br>" +
                        "🎯 <b>Priority Distribution</b><br>" +
                        "• High Priority: %d (%.1f%%)<br>" +
                        "• Medium Priority: %d (%.1f%%)<br>" +
                        "• Low Priority: %d (%.1f%%)<br><br>" +
                        "📈 <b>Status Distribution</b><br>" +
                        "• Completed: %d (%.1f%%)<br>" +
                        "• In Progress: %d (%.1f%%)<br>" +
                        "• Pending: %d (%.1f%%)<br>" +
                        "</div></html>",
                total,
                high, total > 0 ? (high * 100.0 / total) : 0,
                medium, total > 0 ? (medium * 100.0 / total) : 0,
                low, total > 0 ? (low * 100.0 / total) : 0,
                completed, total > 0 ? (completed * 100.0 / total) : 0,
                inProgress, total > 0 ? (inProgress * 100.0 / total) : 0,
                pending, total > 0 ? (pending * 100.0 / total) : 0
        );

        JLabel statsLabel = new JLabel(analytics);
        gbc.gridy = 1;
        contentPanel.add(statsLabel, gbc);

        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Times New Roman", Font.BOLD, 16));
        closeButton.setBackground(new Color(70, 130, 180));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        closeButton.addActionListener(e -> dialog.dispose());

        gbc.gridy = 2;
        contentPanel.add(closeButton, gbc);

        dialog.add(contentPanel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    // ==================== OTHER METHODS ====================
    // (All other methods remain exactly the same - showInsertTaskDialog, showDeleteTaskDialog, etc.)
    // Since you only wanted login page updates, I haven't modified the other methods
    // They are exactly the same as in your original code

    private void showInsertTaskDialog() {
        // First, add the insert task panel to the dashboard card layout if not already added
        boolean insertPanelExists = false;
        for (Component comp : dashboardMainPanel.getComponents()) {
            if (comp.getName() != null && comp.getName().equals("INSERT_TASK")) {
                insertPanelExists = true;
                break;
            }
        }

        if (!insertPanelExists) {
            dashboardMainPanel.add(createInsertTaskPanel(), "INSERT_TASK");
        }

        // Switch to the insert task panel
        dashboardCardLayout.show(dashboardMainPanel, "INSERT_TASK");
    }

    private void showEnhancedCalendarDialog(Component parent, JTextField dateField) {
        // Same as original
        JDialog calendarDialog = new JDialog((Frame) null, "Select Date", true);
        calendarDialog.setSize(350, 400);
        calendarDialog.setLocationRelativeTo(parent);
        calendarDialog.setLayout(new BorderLayout(10, 10));
        calendarDialog.getContentPane().setBackground(Color.WHITE);

        JPanel calendarPanel = new JPanel(new BorderLayout(10, 10));
        calendarPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        calendarPanel.setBackground(Color.WHITE);

        JLabel monthYearLabel = new JLabel("", JLabel.CENTER);
        monthYearLabel.setFont(new Font("Arial", Font.BOLD, 16));
        monthYearLabel.setForeground(new Color(33, 150, 243));

        JPanel daysPanel = new JPanel(new GridLayout(0, 7, 5, 5));
        daysPanel.setBackground(Color.WHITE);

        Calendar cal = Calendar.getInstance();
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            if (!dateField.getText().isEmpty()) {
                Date existingDate = dateFormat.parse(dateField.getText());
                cal.setTime(existingDate);
            }
        } catch (Exception e) { /* Use current date */ }

        updateEnhancedCalendarDisplay(cal, monthYearLabel, daysPanel, dateField, calendarDialog);

        JPanel navPanel = new JPanel(new FlowLayout());
        navPanel.setBackground(Color.WHITE);
        JButton prevButton = createCalendarNavButton("◀");
        JButton nextButton = createCalendarNavButton("▶");
        JButton todayButton = new JButton("Today");
        todayButton.setBackground(new Color(33, 150, 243));
        todayButton.setForeground(Color.WHITE);
        todayButton.setFocusPainted(false);

        prevButton.addActionListener(e -> {
            cal.add(Calendar.MONTH, -1);
            updateEnhancedCalendarDisplay(cal, monthYearLabel, daysPanel, dateField, calendarDialog);
        });
        nextButton.addActionListener(e -> {
            cal.add(Calendar.MONTH, 1);
            updateEnhancedCalendarDisplay(cal, monthYearLabel, daysPanel, dateField, calendarDialog);
        });
        todayButton.addActionListener(e -> {
            cal.setTime(new Date());
            updateEnhancedCalendarDisplay(cal, monthYearLabel, daysPanel, dateField, calendarDialog);
        });

        navPanel.add(prevButton);
        navPanel.add(todayButton);
        navPanel.add(nextButton);
        calendarPanel.add(monthYearLabel, BorderLayout.NORTH);
        calendarPanel.add(daysPanel, BorderLayout.CENTER);
        calendarPanel.add(navPanel, BorderLayout.SOUTH);
        calendarDialog.add(calendarPanel, BorderLayout.CENTER);
        calendarDialog.setVisible(true);
    }

    private JButton createCalendarNavButton(String text) {
        JButton button = new JButton(text);
        button.setBackground(new Color(200, 200, 200));
        button.setForeground(Color.BLACK);
        button.setFocusPainted(false);
        button.setPreferredSize(new Dimension(40, 25));
        return button;
    }

    private void updateEnhancedCalendarDisplay(Calendar cal, JLabel monthYearLabel, JPanel daysPanel,
                                               JTextField dateField, JDialog calendarDialog) {
        daysPanel.removeAll();
        SimpleDateFormat monthFormat = new SimpleDateFormat("MMMM yyyy");
        monthYearLabel.setText(monthFormat.format(cal.getTime()));

        String[] dayNames = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
        for (String dayName : dayNames) {
            JLabel dayLabel = new JLabel(dayName, JLabel.CENTER);
            dayLabel.setFont(new Font("Arial", Font.BOLD, 12));
            dayLabel.setForeground(new Color(100, 100, 100));
            daysPanel.add(dayLabel);
        }

        Calendar firstDay = (Calendar) cal.clone();
        firstDay.set(Calendar.DAY_OF_MONTH, 1);
        int firstDayOfWeek = firstDay.get(Calendar.DAY_OF_WEEK);
        int daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        Calendar today = Calendar.getInstance();

        for (int i = 1; i < firstDayOfWeek; i++) { daysPanel.add(new JLabel("")); }

        for (int day = 1; day <= daysInMonth; day++) {
            JButton dayButton = new JButton(String.valueOf(day));
            dayButton.setFont(new Font("Arial", Font.PLAIN, 12));
            dayButton.setFocusPainted(false);

            if (cal.get(Calendar.YEAR) == today.get(Calendar.YEAR) &&
                    cal.get(Calendar.MONTH) == today.get(Calendar.MONTH) &&
                    day == today.get(Calendar.DAY_OF_MONTH)) {
                dayButton.setBackground(new Color(255, 193, 7));
                dayButton.setForeground(Color.BLACK);
            } else {
                dayButton.setBackground(Color.WHITE);
                dayButton.setForeground(Color.BLACK);
            }

            int finalDay = day;
            dayButton.addActionListener(e -> {
                cal.set(Calendar.DAY_OF_MONTH, finalDay);
                SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                dateField.setText(dateFormat.format(cal.getTime()));
                calendarDialog.dispose();
            });

            dayButton.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
            dayButton.setPreferredSize(new Dimension(35, 30));
            daysPanel.add(dayButton);
        }

        daysPanel.revalidate();
        daysPanel.repaint();
    }

    private void showSimplifiedTimeDialog(Component parent, JTextField timeField) {
        // Same as original
        JDialog timeDialog = new JDialog((Frame) null, "Select Time", true);
        timeDialog.setSize(300, 400);
        timeDialog.setLocationRelativeTo(parent);
        timeDialog.setLayout(new BorderLayout(10, 10));
        timeDialog.getContentPane().setBackground(Color.WHITE);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(Color.WHITE);

        JLabel timeDisplay = new JLabel("12:00", JLabel.CENTER);
        timeDisplay.setFont(new Font("Arial", Font.BOLD, 24));
        timeDisplay.setForeground(new Color(33, 150, 243));
        timeDisplay.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 2));
        mainPanel.add(timeDisplay, BorderLayout.NORTH);

        JPanel ampmPanel = new JPanel(new FlowLayout());
        ampmPanel.setBackground(Color.WHITE);
        ButtonGroup ampmGroup = new ButtonGroup();
        JRadioButton amButton = new JRadioButton("AM");
        JRadioButton pmButton = new JRadioButton("PM");
        amButton.setBackground(Color.WHITE);
        pmButton.setBackground(Color.WHITE);
        ampmGroup.add(amButton);
        ampmGroup.add(pmButton);
        amButton.setSelected(true);
        ampmPanel.add(amButton);
        ampmPanel.add(pmButton);
        mainPanel.add(ampmPanel, BorderLayout.CENTER);

        JPanel hoursPanel = new JPanel(new GridLayout(3, 4, 5, 5));
        hoursPanel.setBackground(Color.WHITE);
        hoursPanel.setBorder(BorderFactory.createTitledBorder("Hours"));
        for (int hour = 1; hour <= 12; hour++) {
            JButton hourButton = new JButton(String.valueOf(hour));
            hourButton.setFont(new Font("Arial", Font.BOLD, 14));
            hourButton.setBackground(new Color(240, 240, 240));
            hourButton.setFocusPainted(false);
            hourButton.addActionListener(e -> {
                String currentTime = timeDisplay.getText();
                String[] parts = currentTime.split(":");
                String minutes = parts.length > 1 ? parts[1] : "00";
                timeDisplay.setText(hourButton.getText() + ":" + minutes);
            });
            hoursPanel.add(hourButton);
        }

        JPanel minutesPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        minutesPanel.setBackground(Color.WHITE);
        minutesPanel.setBorder(BorderFactory.createTitledBorder("Minutes"));
        String[] minuteOptions = {"00", "15", "30", "45"};
        for (String minute : minuteOptions) {
            JButton minuteButton = new JButton(minute);
            minuteButton.setFont(new Font("Arial", Font.BOLD, 14));
            minuteButton.setBackground(new Color(240, 240, 240));
            minuteButton.setFocusPainted(false);
            minuteButton.addActionListener(e -> {
                String currentTime = timeDisplay.getText();
                String[] parts = currentTime.split(":");
                String hour = parts.length > 0 ? parts[0] : "12";
                timeDisplay.setText(hour + ":" + minuteButton.getText());
            });
            minutesPanel.add(minuteButton);
        }

        try {
            if (!timeField.getText().isEmpty()) {
                SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");
                Date existingTime = timeFormat.parse(timeField.getText());
                Calendar tempCal = Calendar.getInstance();
                tempCal.setTime(existingTime);

                int hour = tempCal.get(Calendar.HOUR);
                if (hour == 0) hour = 12;
                int minute = tempCal.get(Calendar.MINUTE);
                minute = (minute / 15) * 15;
                if (minute == 60) minute = 0;
                timeDisplay.setText(String.format("%d:%02d", hour, minute));

                if (tempCal.get(Calendar.AM_PM) == Calendar.AM) {
                    amButton.setSelected(true);
                } else {
                    pmButton.setSelected(true);
                }
            }
        } catch (Exception e) {
            timeDisplay.setText("12:00");
            amButton.setSelected(true);
        }

        JPanel controlPanel = new JPanel(new FlowLayout());
        controlPanel.setBackground(Color.WHITE);
        JButton okButton = new JButton("OK");
        okButton.setBackground(new Color(76, 175, 80));
        okButton.setForeground(Color.WHITE);
        okButton.setFocusPainted(false);
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(244, 67, 54));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);

        okButton.addActionListener(e -> {
            try {
                String time = timeDisplay.getText();
                String ampm = amButton.isSelected() ? "AM" : "PM";
                if (!time.matches("\\d{1,2}:\\d{2}")) {
                    JOptionPane.showMessageDialog(timeDialog, "Invalid time format!");
                    return;
                }
                timeField.setText(time + " " + ampm);
                timeDialog.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(timeDialog, "Error selecting time!");
            }
        });

        cancelButton.addActionListener(e -> timeDialog.dispose());
        controlPanel.add(okButton);
        controlPanel.add(cancelButton);

        JPanel timeSelectionPanel = new JPanel(new BorderLayout());
        timeSelectionPanel.add(hoursPanel, BorderLayout.NORTH);
        timeSelectionPanel.add(minutesPanel, BorderLayout.CENTER);
        mainPanel.add(timeSelectionPanel, BorderLayout.SOUTH);

        timeDialog.add(mainPanel, BorderLayout.CENTER);
        timeDialog.add(controlPanel, BorderLayout.SOUTH);
        timeDialog.setVisible(true);
    }

    private JPanel createInsertTaskPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(45, 45, 60)); // Dark blue-gray background

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 15, 10, 15); // Reduced insets
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Main container for better centering
        JPanel insertContainer = new JPanel(new GridBagLayout());
        insertContainer.setBackground(new Color(60, 60, 80));
        insertContainer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(30, 30, 30, 30) // Reduced padding
        ));

        GridBagConstraints containerGbc = new GridBagConstraints();
        containerGbc.insets = new Insets(10, 15, 10, 15); // Reduced insets
        containerGbc.fill = GridBagConstraints.HORIZONTAL;

        // Title Label - Reduced font size
        JLabel titleLabel = new JLabel("ADD NEW TASK");
        titleLabel.setFont(new Font("Times New Roman", Font.BOLD, 36)); // Reduced from 42 to 36
        titleLabel.setForeground(new Color(255, 215, 0)); // Gold color
        containerGbc.gridx = 0; containerGbc.gridy = 0; containerGbc.gridwidth = 2;
        containerGbc.anchor = GridBagConstraints.CENTER;
        insertContainer.add(titleLabel, containerGbc);

        // Task Title Label - Reduced font size
        JLabel taskTitleLabel = new JLabel("TASK TITLE");
        taskTitleLabel.setFont(new Font("Times New Roman", Font.BOLD, 20)); // Reduced from 24 to 20
        taskTitleLabel.setForeground(Color.WHITE);
        containerGbc.gridy = 1;
        containerGbc.gridwidth = 1;
        containerGbc.anchor = GridBagConstraints.WEST;
        insertContainer.add(taskTitleLabel, containerGbc);

        // Task Title Field - Smaller input box
        JTextField titleField = new JTextField(20);
        titleField.setFont(new Font("Times New Roman", Font.PLAIN, 18)); // Reduced from 20 to 18
        titleField.setPreferredSize(new Dimension(300, 40)); // Reduced from 400x50 to 300x40
        titleField.setMinimumSize(new Dimension(300, 40));
        titleField.setMaximumSize(new Dimension(300, 40));
        titleField.setBackground(new Color(80, 80, 100));
        titleField.setForeground(Color.BLACK);
        titleField.setCaretColor(Color.WHITE);
        titleField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(8, 12, 8, 12) // Reduced padding
        ));
        containerGbc.gridx = 1;
        insertContainer.add(titleField, containerGbc);

        // Description Label - Reduced font size
        JLabel descLabel = new JLabel("DESCRIPTION");
        descLabel.setFont(new Font("Times New Roman", Font.BOLD, 20)); // Reduced from 24 to 20
        descLabel.setForeground(Color.WHITE);
        containerGbc.gridx = 0; containerGbc.gridy = 2;
        insertContainer.add(descLabel, containerGbc);

        // Description TextArea - Smaller
        JTextArea descArea = new JTextArea(3, 20); // Reduced rows from 4 to 3
        descArea.setLineWrap(true);
        descArea.setWrapStyleWord(true);
        descArea.setFont(new Font("Times New Roman", Font.PLAIN, 16)); // Reduced from 18 to 16

        JScrollPane descScroll = new JScrollPane(descArea);
        descScroll.setPreferredSize(new Dimension(300, 80)); // Reduced from 400x120 to 300x80
        descScroll.setMinimumSize(new Dimension(300, 80));
        descScroll.setMaximumSize(new Dimension(300, 80));
        descScroll.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(8, 8, 8, 8) // Reduced padding
        ));
        descArea.setBackground(new Color(80, 80, 100));
        descArea.setForeground(Color.BLACK);
        descArea.setCaretColor(Color.WHITE);
        descScroll.getViewport().setBackground(new Color(80, 80, 100));
        containerGbc.gridx = 1;
        insertContainer.add(descScroll, containerGbc);

        // Priority Label - Reduced font size
        JLabel priorityLabel = new JLabel("PRIORITY");
        priorityLabel.setFont(new Font("Times New Roman", Font.BOLD, 20)); // Reduced from 24 to 20
        priorityLabel.setForeground(Color.WHITE);
        containerGbc.gridx = 0; containerGbc.gridy = 3;
        insertContainer.add(priorityLabel, containerGbc);

        // Priority ComboBox - Smaller
        String[] priorities = {"Low", "Medium", "High"};
        JComboBox<String> priorityBox = new JComboBox<>(priorities);
        priorityBox.setFont(new Font("Arial", Font.PLAIN, 18)); // Reduced from 20 to 18
        priorityBox.setPreferredSize(new Dimension(300, 40)); // Reduced from 400x50 to 300x40
        priorityBox.setMinimumSize(new Dimension(300, 40));
        priorityBox.setMaximumSize(new Dimension(300, 40));
        priorityBox.setBackground(new Color(80, 80, 100));
        priorityBox.setForeground(Color.BLACK);
        priorityBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value,
                                                          int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                setBackground(new Color(80, 80, 100));
                setForeground(Color.WHITE);
                setFont(new Font("Times New Roman", Font.PLAIN, 18)); // Reduced from 20 to 18
                if (isSelected) {
                    setBackground(new Color(100, 100, 140));
                }
                return this;
            }
        });
        priorityBox.setUI(new BasicComboBoxUI() {
            @Override
            protected JButton createArrowButton() {
                JButton button = super.createArrowButton();
                button.setBackground(new Color(100, 100, 140));
                button.setForeground(Color.WHITE);
                button.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140)));
                return button;
            }
        });
        priorityBox.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(8, 12, 8, 12) // Reduced padding
        ));
        containerGbc.gridx = 1;
        insertContainer.add(priorityBox, containerGbc);

        // Start Date Label - Reduced font size
        JLabel startDateLabel = new JLabel("START DATE");
        startDateLabel.setFont(new Font("Times New Roman", Font.BOLD, 20)); // Reduced from 24 to 20
        startDateLabel.setForeground(Color.WHITE);
        containerGbc.gridx = 0; containerGbc.gridy = 4;
        insertContainer.add(startDateLabel, containerGbc);

        // Start Date Panel - Smaller
        JPanel startDatePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0)); // Reduced gap
        startDatePanel.setBackground(new Color(60, 60, 80));

        JTextField startDateField = new JTextField(10); // Reduced columns
        startDateField.setEditable(false);
        startDateField.setFont(new Font("Times New Roman", Font.PLAIN, 16)); // Reduced from 20 to 16
        startDateField.setPreferredSize(new Dimension(220, 35)); // Reduced size
        startDateField.setBackground(new Color(80, 80, 100));
        startDateField.setForeground(Color.WHITE);
        startDateField.setCaretColor(Color.WHITE);
        startDateField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(6, 10, 6, 10) // Reduced padding
        ));

        JButton startDateButton = new JButton("📅");
        startDateButton.setFont(new Font("Times New Roman", Font.BOLD, 16)); // Reduced from 20 to 16
        startDateButton.setPreferredSize(new Dimension(45, 35)); // Reduced size
        startDateButton.setBackground(new Color(100, 100, 140));
        startDateButton.setForeground(Color.WHITE);
        startDateButton.setFocusPainted(false);
        startDateButton.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140), 2));
        startDateButton.setToolTipText("Select Start Date");
        startDateButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                startDateButton.setBackground(new Color(120, 120, 160));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                startDateButton.setBackground(new Color(100, 100, 140));
            }
        });

        startDatePanel.add(startDateField);
        startDatePanel.add(startDateButton);
        containerGbc.gridx = 1;
        insertContainer.add(startDatePanel, containerGbc);

        // Start Time Label - Reduced font size
        JLabel startTimeLabel = new JLabel("START TIME");
        startTimeLabel.setFont(new Font("Times New Roman", Font.BOLD, 20)); // Reduced from 24 to 20
        startTimeLabel.setForeground(Color.WHITE);
        containerGbc.gridx = 0; containerGbc.gridy = 5;
        insertContainer.add(startTimeLabel, containerGbc);

        // Start Time Panel - Smaller
        JPanel startTimePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0)); // Reduced gap
        startTimePanel.setBackground(new Color(60, 60, 80));

        JTextField startTimeField = new JTextField(8); // Reduced columns
        startTimeField.setEditable(false);
        startTimeField.setFont(new Font("Times New Roman", Font.PLAIN, 16)); // Reduced from 20 to 16
        startTimeField.setPreferredSize(new Dimension(220, 35)); // Reduced size
        startTimeField.setBackground(new Color(80, 80, 100));
        startTimeField.setForeground(Color.WHITE);
        startTimeField.setCaretColor(Color.WHITE);
        startTimeField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(6, 10, 6, 10) // Reduced padding
        ));

        JButton startTimeButton = new JButton("🕒");
        startTimeButton.setFont(new Font("Times New Roman", Font.BOLD, 16)); // Reduced from 20 to 16
        startTimeButton.setPreferredSize(new Dimension(45, 35)); // Reduced size
        startTimeButton.setBackground(new Color(100, 100, 140));
        startTimeButton.setForeground(Color.WHITE);
        startTimeButton.setFocusPainted(false);
        startTimeButton.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140), 2));
        startTimeButton.setToolTipText("Select Start Time");
        startTimeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                startTimeButton.setBackground(new Color(120, 120, 160));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                startTimeButton.setBackground(new Color(100, 100, 140));
            }
        });

        startTimePanel.add(startTimeField);
        startTimePanel.add(startTimeButton);
        containerGbc.gridx = 1;
        insertContainer.add(startTimePanel, containerGbc);

        // End Date Label - Reduced font size
        JLabel endDateLabel = new JLabel("END DATE");
        endDateLabel.setFont(new Font("Times New Roman", Font.BOLD, 20)); // Reduced from 24 to 20
        endDateLabel.setForeground(Color.WHITE);
        containerGbc.gridx = 0; containerGbc.gridy = 6;
        insertContainer.add(endDateLabel, containerGbc);

        // End Date Panel - Smaller
        JPanel endDatePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0)); // Reduced gap
        endDatePanel.setBackground(new Color(60, 60, 80));

        JTextField endDateField = new JTextField(10); // Reduced columns
        endDateField.setEditable(false);
        endDateField.setFont(new Font("Times New Roman", Font.PLAIN, 16)); // Reduced from 20 to 16
        endDateField.setPreferredSize(new Dimension(220, 35)); // Reduced size
        endDateField.setBackground(new Color(80, 80, 100));
        endDateField.setForeground(Color.WHITE);
        endDateField.setCaretColor(Color.WHITE);
        endDateField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(6, 10, 6, 10) // Reduced padding
        ));

        JButton endDateButton = new JButton("📅");
        endDateButton.setFont(new Font("Times New Roman", Font.BOLD, 16)); // Reduced from 20 to 16
        endDateButton.setPreferredSize(new Dimension(45, 35)); // Reduced size
        endDateButton.setBackground(new Color(100, 100, 140));
        endDateButton.setForeground(Color.WHITE);
        endDateButton.setFocusPainted(false);
        endDateButton.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140), 2));
        endDateButton.setToolTipText("Select End Date");
        endDateButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                endDateButton.setBackground(new Color(120, 120, 160));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                endDateButton.setBackground(new Color(100, 100, 140));
            }
        });

        endDatePanel.add(endDateField);
        endDatePanel.add(endDateButton);
        containerGbc.gridx = 1;
        insertContainer.add(endDatePanel, containerGbc);

        // End Time Label - Reduced font size
        JLabel endTimeLabel = new JLabel("END TIME");
        endTimeLabel.setFont(new Font("Times New Roman", Font.BOLD, 20)); // Reduced from 24 to 20
        endTimeLabel.setForeground(Color.WHITE);
        containerGbc.gridx = 0; containerGbc.gridy = 7;
        insertContainer.add(endTimeLabel, containerGbc);

        // End Time Panel - Smaller
        JPanel endTimePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0)); // Reduced gap
        endTimePanel.setBackground(new Color(60, 60, 80));

        JTextField endTimeField = new JTextField(8); // Reduced columns
        endTimeField.setEditable(false);
        endTimeField.setFont(new Font("Times New Roman", Font.PLAIN, 16)); // Reduced from 20 to 16
        endTimeField.setPreferredSize(new Dimension(220, 35)); // Reduced size
        endTimeField.setBackground(new Color(80, 80, 100));
        endTimeField.setForeground(Color.WHITE);
        endTimeField.setCaretColor(Color.WHITE);
        endTimeField.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(6, 10, 6, 10) // Reduced padding
        ));

        JButton endTimeButton = new JButton("🕒");
        endTimeButton.setFont(new Font("Times New Roman", Font.BOLD, 16)); // Reduced from 20 to 16
        endTimeButton.setPreferredSize(new Dimension(45, 35)); // Reduced size
        endTimeButton.setBackground(new Color(100, 100, 140));
        endTimeButton.setForeground(Color.WHITE);
        endTimeButton.setFocusPainted(false);
        endTimeButton.setBorder(BorderFactory.createLineBorder(new Color(100, 100, 140), 2));
        endTimeButton.setToolTipText("Select End Time");
        endTimeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                endTimeButton.setBackground(new Color(120, 120, 160));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                endTimeButton.setBackground(new Color(100, 100, 140));
            }
        });

        endTimePanel.add(endTimeField);
        endTimePanel.add(endTimeButton);
        containerGbc.gridx = 1;
        insertContainer.add(endTimePanel, containerGbc);

        // Set default date/time values
        AtomicReference<Calendar> cal = new AtomicReference<>(Calendar.getInstance());
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a");

        startDateField.setText(dateFormat.format(cal.get().getTime()));
        startTimeField.setText(timeFormat.format(cal.get().getTime()));

        cal.get().add(Calendar.HOUR, 1);
        endDateField.setText(dateFormat.format(cal.get().getTime()));
        endTimeField.setText(timeFormat.format(cal.get().getTime()));

        // Add action listeners for date/time buttons
        startDateButton.addActionListener(e -> showEnhancedCalendarDialog(panel, startDateField));
        endDateButton.addActionListener(e -> showEnhancedCalendarDialog(panel, endDateField));
        startTimeButton.addActionListener(e -> showSimplifiedTimeDialog(panel, startTimeField));
        endTimeButton.addActionListener(e -> showSimplifiedTimeDialog(panel, endTimeField));

        // Error Message Label
        JLabel errorLabel = new JLabel(" ");
        errorLabel.setFont(new Font("Times New Roman", Font.PLAIN, 14)); // Reduced from 16 to 14
        errorLabel.setForeground(new Color(255, 100, 100));
        containerGbc.gridx = 0; containerGbc.gridy = 8;
        containerGbc.gridwidth = 2;
        containerGbc.anchor = GridBagConstraints.CENTER;
        insertContainer.add(errorLabel, containerGbc);

        // Button Panel
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 0)); // Reduced gap
        buttonPanel.setBackground(new Color(60, 60, 80));
        containerGbc.gridy = 9;
        containerGbc.gridwidth = 2;
        insertContainer.add(buttonPanel, containerGbc);

        // Back Button - Smaller
        JButton backButton = new JButton("BACK");
        backButton.setFont(new Font("Times New Roman", Font.BOLD, 15)); // Reduced from 24 to 20
        backButton.setPreferredSize(new Dimension(140, 50)); // Reduced from 180x60 to 140x50
        backButton.setBackground(new Color(120, 120, 120));
        backButton.setForeground(Color.WHITE);
        backButton.setFocusPainted(false);
        backButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 100), 2),
                BorderFactory.createEmptyBorder(8, 20, 8, 20) // Reduced padding
        ));
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        backButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                backButton.setBackground(new Color(140, 140, 140));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                backButton.setBackground(new Color(120, 120, 120));
            }
        });

        backButton.addActionListener(e -> {
            dashboardCardLayout.show(dashboardMainPanel, "MAIN_DASHBOARD");
        });

        // Add Task Button - Smaller
        JButton addButton = new JButton("ADD TASK");
        addButton.setFont(new Font("Times New Roman", Font.BOLD, 15)); // Reduced from 24 to 20
        addButton.setPreferredSize(new Dimension(140, 50)); // Reduced from 180x60 to 140x50
        addButton.setBackground(new Color(70, 130, 180)); // Steel blue
        addButton.setForeground(Color.WHITE);
        addButton.setFocusPainted(false);
        addButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50, 110, 160), 2),
                BorderFactory.createEmptyBorder(8, 20, 8, 20) // Reduced padding
        ));
        addButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effect
        addButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                addButton.setBackground(new Color(60, 120, 170));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                addButton.setBackground(new Color(70, 130, 180));
            }
        });

        buttonPanel.add(backButton);
        buttonPanel.add(addButton);

        // Add Task Action
        addButton.addActionListener(e -> {
            String title = titleField.getText().trim();
            String desc = descArea.getText().trim();
            int priority = priorityBox.getSelectedIndex() + 1;

            if (title.isEmpty()) {
                errorLabel.setText("Please enter task title!");
                return;
            }

            if (startDateField.getText().isEmpty() || startTimeField.getText().isEmpty() ||
                    endDateField.getText().isEmpty() || endTimeField.getText().isEmpty()) {
                errorLabel.setText("Please select both start and end date/time!");
                return;
            }

            try {
                SimpleDateFormat dateTimeFormat = new SimpleDateFormat("dd/MM/yyyy hh:mm a");
                Date startTime = dateTimeFormat.parse(startDateField.getText() + " " + startTimeField.getText());
                Date endTime = dateTimeFormat.parse(endDateField.getText() + " " + endTimeField.getText());

                if (endTime.before(startTime)) {
                    errorLabel.setText("End time cannot be before start time!");
                    return;
                }

                Task task = new Task(taskIdCounter++, title, desc, priority, startTime, endTime);
                priorityQueue.add(task);
                taskBST.insert(task);
                activityLog.enqueue("Task added: " + title + " (Start: " + task.getFormattedStartTime() + ", End: " + task.getFormattedEndTime() + ")");

                // Show success message
                errorLabel.setForeground(new Color(100, 255, 100));
                errorLabel.setText("Task added successfully!");

                // Clear fields after successful addition
                titleField.setText("");
                descArea.setText("");
                priorityBox.setSelectedIndex(0);

                // Reset to current date/time
                cal.set(Calendar.getInstance());
                startDateField.setText(dateFormat.format(cal.get().getTime()));
                startTimeField.setText(timeFormat.format(cal.get().getTime()));
                cal.get().add(Calendar.HOUR, 1);
                endDateField.setText(dateFormat.format(cal.get().getTime()));
                endTimeField.setText(timeFormat.format(cal.get().getTime()));

                // Clear error message after 3 seconds
                new Timer(3000, ev -> {
                    errorLabel.setText(" ");
                    errorLabel.setForeground(new Color(255, 100, 100));
                }).start();

            } catch (Exception ex) {
                errorLabel.setText("Error in date/time format. Please check your selections.");
            }
        });

        // Add enter key support for title field
        titleField.addActionListener(e -> addButton.doClick());

        // Add insert container to main panel
        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(insertContainer, gbc);

        return panel;
    }


    private void showDeleteTaskDialog() {
        // Remove any existing DELETE_TASK panel
        Component toRemove = null;
        for (Component comp : dashboardMainPanel.getComponents()) {
            if (comp.getName() != null && comp.getName().equals("DELETE_TASK_PANEL")) {
                toRemove = comp;
                break;
            }
        }

        if (toRemove != null) {
            dashboardMainPanel.remove(toRemove);
        }

        // Create fresh delete panel with current data
        JPanel freshDeletePanel = createDeleteTaskPanel();
        freshDeletePanel.setName("DELETE_TASK_PANEL");
        dashboardMainPanel.add(freshDeletePanel, "DELETE_TASK");

        // Switch to delete panel
        dashboardCardLayout.show(dashboardMainPanel, "DELETE_TASK");

        // Force UI refresh
        dashboardMainPanel.revalidate();
        dashboardMainPanel.repaint();
    }

    // Add this method to create the delete task panel
    private JPanel createDeleteTaskPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(new Color(45, 45, 60));
        panel.setName("DELETE_TASK_PANEL");

        // Create main container with BorderLayout
        JPanel mainContainer = new JPanel(new BorderLayout());
        mainContainer.setBackground(new Color(45, 45, 60));
        mainContainer.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Title
        JLabel titleLabel = new JLabel(" Delete Task", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 80));
        titleLabel.setForeground(new Color(255, 215, 0));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        mainContainer.add(titleLabel, BorderLayout.NORTH);

        // Store tasks as a field to access them in listeners
        final List<Task>[] tasksHolder = new List[]{taskBST.inorderTraversal()};

        if (tasksHolder[0].isEmpty()) {
            JLabel noTasksLabel = new JLabel("No tasks available to delete!", JLabel.CENTER);
            noTasksLabel.setFont(new Font("Times New Roman", Font.BOLD, 28));
            noTasksLabel.setForeground(Color.WHITE);
            noTasksLabel.setBorder(BorderFactory.createEmptyBorder(50, 0, 50, 0));
            mainContainer.add(noTasksLabel, BorderLayout.CENTER);
        } else {
            // Create the task table panel
            JPanel tablePanel = new JPanel(new BorderLayout());
            tablePanel.setBackground(new Color(45, 45, 60));

            // Table title
            JLabel tableTitle = new JLabel("  Select a task to delete (Click on any task)", JLabel.CENTER);
            tableTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
            tableTitle.setForeground(new Color(255, 215, 0));
            tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
            tablePanel.add(tableTitle, BorderLayout.NORTH);

            // Create the table with task data
            String[] columns = {"ID", "Task Name", "Status", "Priority", "Start Time", "End Time"};
            DefaultTableModel model = new DefaultTableModel(columns, 0) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false; // No cells are editable
                }
            };

            // Add tasks to table
            for (Task task : tasksHolder[0]) {
                model.addRow(new Object[]{
                        task.id,
                        task.title,
                        task.status,
                        task.getPriorityString(),
                        task.getFormattedStartTime(),
                        task.getFormattedEndTime()
                });
            }

            // Create table with single selection
            JTable taskTable = new JTable(model);
            taskTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

            // Store the table reference for later updates
            final JTable[] tableHolder = new JTable[]{taskTable};

            // Basic table styling
            taskTable.setFont(new Font("Times New Roman", Font.PLAIN, 18));
            taskTable.setRowHeight(35);
            taskTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 20));
            taskTable.getTableHeader().setBackground(new Color(80, 80, 100));
            taskTable.getTableHeader().setForeground(new Color(255, 215, 0));
            taskTable.setGridColor(new Color(100, 100, 140));
            taskTable.setShowGrid(true);
            taskTable.setSelectionBackground(new Color(70, 130, 180));
            taskTable.setSelectionForeground(Color.WHITE);

            // Set column widths
            taskTable.getColumnModel().getColumn(0).setPreferredWidth(60);   // ID
            taskTable.getColumnModel().getColumn(1).setPreferredWidth(300);  // Task Name
            taskTable.getColumnModel().getColumn(2).setPreferredWidth(120);  // Status
            taskTable.getColumnModel().getColumn(3).setPreferredWidth(100);  // Priority
            taskTable.getColumnModel().getColumn(4).setPreferredWidth(180);  // Start Time
            taskTable.getColumnModel().getColumn(5).setPreferredWidth(180);  // End Time

            // Custom cell renderer for color coding
            taskTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable table, Object value,
                                                               boolean isSelected, boolean hasFocus,
                                                               int row, int column) {
                    Component c = super.getTableCellRendererComponent(table, value,
                            isSelected, hasFocus, row, column);

                    // Default: White text on dark background
                    c.setBackground(new Color(60, 60, 80));
                    c.setForeground(Color.WHITE);

                    // If row is selected, use selection colors
                    if (isSelected) {
                        return c;
                    }

                    // Get task for this row
                    Task task = tasksHolder[0].get(row);

                    // Color coding based on status (column 2)
                    if (column == 2 && value != null) {
                        String status = value.toString();
                        if (status.equals("Completed")) {
                            c.setBackground(new Color(0, 100, 0)); // Dark Green
                            c.setForeground(Color.WHITE);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (status.equals("In Progress")) {
                            c.setBackground(new Color(200, 150, 0)); // Orange/Yellow
                            c.setForeground(Color.WHITE);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (status.equals("Pending")) {
                            c.setBackground(new Color(150, 0, 0)); // Dark Red
                            c.setForeground(Color.WHITE);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        }
                    }

                    // Color priority column
                    if (column == 3 && value != null) {
                        String priority = value.toString();
                        if (priority.equals("High")) {
                            c.setForeground(Color.RED);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (priority.equals("Medium")) {
                            c.setForeground(Color.BLACK);
                            c.setFont(c.getFont().deriveFont(Font.BOLD));
                        } else if (priority.equals("Low")) {
                            c.setForeground(Color.GREEN);
                        }
                    }

                    // Color ID column
                    if (column == 0) {
                        c.setForeground(new Color(255, 215, 0)); // Gold
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    }

                    // Color task name column
                    if (column == 1) {
                        c.setForeground(new Color(200, 220, 255)); // Light blue
                    }

                    // Center align ID, Status, and Priority columns
                    if (column == 0 || column == 2 || column == 3) {
                        ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);
                    } else {
                        ((JLabel) c).setHorizontalAlignment(SwingConstants.LEFT);
                    }

                    return c;
                }
            });

            // Create scroll pane
            JScrollPane scrollPane = new JScrollPane(taskTable);
            scrollPane.setPreferredSize(new Dimension(1100, 400));
            scrollPane.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                    BorderFactory.createEmptyBorder(5, 5, 5, 5)
            ));
            scrollPane.getViewport().setBackground(new Color(60, 60, 80));

            // Add scroll pane to panel
            tablePanel.add(scrollPane, BorderLayout.CENTER);

            mainContainer.add(tablePanel, BorderLayout.CENTER);
        }

        panel.add(mainContainer, BorderLayout.CENTER);

        // BOTTOM: Back and Delete buttons
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
        bottomPanel.setBackground(new Color(45, 45, 60));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 40, 20));

        // Back button
        JButton backButton = createBackButton();
        backButton.addActionListener(e -> dashboardCardLayout.show(dashboardMainPanel, "MAIN_DASHBOARD"));
        bottomPanel.add(backButton);

        // Delete button (only shown if there are tasks)
        if (!tasksHolder[0].isEmpty()) {
            JButton deleteButton = new JButton("  Delete Task");
            deleteButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
            deleteButton.setBackground(new Color(180, 70, 70));
            deleteButton.setForeground(Color.WHITE);
            deleteButton.setFocusPainted(false);
            deleteButton.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(150, 50, 50), 2),
                    BorderFactory.createEmptyBorder(10, 20, 10, 20)
            ));
            deleteButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

            // Add hover effect for delete button
            deleteButton.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    deleteButton.setBackground(new Color(190, 80, 80));
                }
                @Override
                public void mouseExited(MouseEvent e) {
                    deleteButton.setBackground(new Color(180, 70, 70));
                }
            });

            deleteButton.addActionListener(e -> {
                // Find the task table
                JTable taskTable = findDeleteTaskTable(mainContainer);  // Fixed method name
                if (taskTable == null) return;

                int selectedRow = taskTable.getSelectedRow();

                if (selectedRow == -1) {
                    JOptionPane.showMessageDialog(panel,
                            "Please select a task to delete!\n\n" +
                                    "Click on any task row to select it.",
                            "No Task Selected",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }

                Task selectedTask = tasksHolder[0].get(selectedRow);
                deleteTaskWithConfirmation(selectedTask, taskTable, selectedRow);
            });

            bottomPanel.add(deleteButton);
        }

        panel.add(bottomPanel, BorderLayout.SOUTH);

        return panel;
    }

    // Method to delete task with confirmation
    // Method to delete task with confirmation
    private void deleteTaskWithConfirmation(Task task, JTable taskTable, int selectedRow) {
        int confirm = JOptionPane.showConfirmDialog(this,
                "Are you sure you want to delete this task?\n\n" +
                        "Task: " + task.title + "\n" +
                        "ID: " + task.id + "\n" +
                        "Status: " + task.status + "\n\n" +
                        "This action cannot be undone!",
                "Confirm Delete Task",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            // Delete from data structures
            taskBST.delete(task.id);
            priorityQueue.remove(task);

            // Log the activity
            activityLog.enqueue("Task deleted: " + task.title + " (ID: " + task.id + ")");

            // Remove from table
            DefaultTableModel model = (DefaultTableModel) taskTable.getModel();
            model.removeRow(selectedRow);

            // Update the tasks holder
            List<Task> updatedTasks = taskBST.inorderTraversal();

            // Show success message
//            JOptionPane.showMessageDialog(this,
//                    "✅ Task Deleted Successfully!\n\n" +
//                            "Task: " + task.title + "\n" +
//                            "ID: " + task.id + "\n\n" +
//                            "Task has been removed from the system.",
//                    "Task Deleted",
//                    JOptionPane.INFORMATION_MESSAGE);

            // IMPORTANT: After deletion, return to dashboard instead of staying on delete panel
            // This prevents the panel from getting stuck with outdated data
            dashboardCardLayout.show(dashboardMainPanel, "MAIN_DASHBOARD");
        }
    }

    // Helper method to find the task table in the container (reuse from update status)
    // Helper method to find the task table in delete panel container
    private JTable findDeleteTaskTable(Container container) {
        for (Component comp : container.getComponents()) {
            if (comp instanceof JTable) {
                return (JTable) comp;
            } else if (comp instanceof Container) {
                JTable found = findDeleteTaskTable((Container) comp);
                if (found != null) return found;
            }
        }
        return null;
    }


    private void showToDoList() {
        List<Task> tasks = priorityQueue.getAllTasks();
        if (tasks.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks in queue!");
            return;
        }

        // Create a custom dialog with table layout
        JDialog dialog = new JDialog(this, "To-Do List (Priority Order)", true);
        dialog.setSize(1200, 700);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout());
        dialog.getContentPane().setBackground(new Color(45, 45, 60));

        // Title - Same as status view
        JLabel titleLabel = new JLabel("  To-Do List Dashboard", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.PLAIN, 50));
        titleLabel.setForeground(new Color(255, 215, 0));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 20, 0));
        dialog.add(titleLabel, BorderLayout.NORTH);

        // Sort tasks by priority and status
        List<Task> sortedTasks = new ArrayList<>(tasks);
        sortedTasks.sort((t1, t2) -> {
            // First by priority (High to Low)
            int priorityCompare = Integer.compare(t2.priority, t1.priority);
            if (priorityCompare != 0) return priorityCompare;

            // Then by status (Pending > In Progress > Completed)
            int statusOrder1 = getStatusOrder(t1.status);
            int statusOrder2 = getStatusOrder(t2.status);
            int statusCompare = Integer.compare(statusOrder1, statusOrder2);
            if (statusCompare != 0) return statusCompare;

            // Then by start time (earliest first)
            return t1.startTime.compareTo(t2.startTime);
        });

        // Create the table panel directly here - Same layout as status view
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(new Color(45, 45, 60));

        // Table title with task count
        JLabel tableTitle = new JLabel("  Priority Tasks - " + sortedTasks.size() + " tasks found", JLabel.CENTER);
        tableTitle.setFont(new Font("Times New Roman", Font.BOLD, 24));
        tableTitle.setForeground(new Color(255, 215, 0));
        tableTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        tablePanel.add(tableTitle, BorderLayout.NORTH);

        // Create the table with task data - Added Time Status column
        String[] columns = {"ID", "Task Name", "Priority", "Start Time", "End Time", "Status", "Time Status"};
        DefaultTableModel model = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        // Add tasks to table
        for (Task task : sortedTasks) {
            model.addRow(new Object[]{
                    task.id,
                    task.title,
                    task.getPriorityString(),
                    task.getFormattedStartTime(),
                    task.getFormattedEndTime(),
                    task.status,  // This shows the CURRENT status - Same as status view
                    getTimeStatusWithRemaining(task) // Enhanced time status
            });
        }

        // Create table
        JTable taskTable = new JTable(model);

        // Basic table styling - Same as status view
        taskTable.setFont(new Font("Times New Roman", Font.PLAIN, 18));
        taskTable.setRowHeight(35); // Taller rows for better visibility
        taskTable.getTableHeader().setFont(new Font("Times New Roman", Font.BOLD, 20));
        taskTable.getTableHeader().setBackground(new Color(80, 80, 100));
        taskTable.getTableHeader().setForeground(new Color(255, 215, 0)); // Gold header text
        taskTable.setGridColor(new Color(100, 100, 140));
        taskTable.setShowGrid(true);
        taskTable.setSelectionBackground(new Color(70, 130, 180));
        taskTable.setSelectionForeground(Color.WHITE);

        // Set column widths
        taskTable.getColumnModel().getColumn(0).setPreferredWidth(60);  // ID
        taskTable.getColumnModel().getColumn(1).setPreferredWidth(250); // Task Name
        taskTable.getColumnModel().getColumn(2).setPreferredWidth(100); // Priority
        taskTable.getColumnModel().getColumn(3).setPreferredWidth(180); // Start Time
        taskTable.getColumnModel().getColumn(4).setPreferredWidth(180); // End Time
        taskTable.getColumnModel().getColumn(5).setPreferredWidth(120); // Status
        taskTable.getColumnModel().getColumn(6).setPreferredWidth(150); // Time Status

        // Custom cell renderer for status-based coloring - SAME AS STATUS VIEW
        taskTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

                // Default: White text on dark background - SAME AS STATUS VIEW
                c.setBackground(new Color(60, 60, 80));
                c.setForeground(Color.WHITE);

                // Only color the status column (column 5) - SAME AS STATUS VIEW
                if (column == 5 && value != null) {
                    String status = value.toString();

                    if (status.equals("Completed")) {
                        c.setBackground(new Color(0, 100, 0)); // Dark Green background
                        c.setForeground(Color.WHITE); // White text
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (status.equals("In Progress")) {
                        c.setBackground(Color.YELLOW); // Yellow background
                        c.setForeground(Color.BLACK); // Black text
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (status.equals("Pending")) {
                        c.setBackground(Color.RED); // Red background
                        c.setForeground(Color.WHITE); // White text
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    }
                }

                // Color priority column - SAME AS STATUS VIEW
                if (column == 2 && value != null) {
                    String priority = value.toString();
                    if (priority.equals("High")) {
                        c.setForeground(Color.CYAN); // Cyan
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (priority.equals("Medium")) {
                        c.setForeground(Color.BLACK); // Black
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (priority.equals("Low")) {
                        c.setForeground(new Color(100, 255, 100)); // Light Green
                    }
                }

                // Color Time Status column (column 6) - NEW
                if (column == 6 && value != null) {
                    String timeStatus = value.toString();

                    if (timeStatus.startsWith("✅ Done")) {
                        c.setForeground(new Color(0, 200, 0)); // Bright Green
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (timeStatus.contains("overdue") || timeStatus.contains("Overdue")) {
                        c.setForeground(new Color(255, 50, 50)); // Bright Red
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (timeStatus.contains("1 hour") || timeStatus.contains("30 min")) {
                        c.setForeground(new Color(255, 100, 100)); // Red
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (timeStatus.contains("2 hours") || timeStatus.contains("3 hours")) {
                        c.setForeground(new Color(255, 200, 100)); // Orange/Yellow
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    } else if (timeStatus.contains("> 3 hours") || timeStatus.contains("Tomorrow")) {
                        c.setForeground(new Color(100, 255, 100)); // Green
                        c.setFont(c.getFont().deriveFont(Font.BOLD));
                    }
                }

                // Color ID column - SAME AS STATUS VIEW
                if (column == 0) {
                    c.setForeground(new Color(255, 215, 0)); // Gold
                    c.setFont(c.getFont().deriveFont(Font.BOLD));
                }

                // Center align all cells - SAME AS STATUS VIEW
                ((JLabel) c).setHorizontalAlignment(SwingConstants.CENTER);

                return c;
            }
        });

        // Create scroll pane - SAME AS STATUS VIEW
        JScrollPane scrollPane = new JScrollPane(taskTable);
        scrollPane.setPreferredSize(new Dimension(1100, 400));
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(100, 100, 140), 2),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)
        ));
        scrollPane.getViewport().setBackground(new Color(60, 60, 80));

        // Add scroll pane to panel
        tablePanel.add(scrollPane, BorderLayout.CENTER);
        dialog.add(tablePanel, BorderLayout.CENTER);

        // BOTTOM: Close Button only - Similar to status view's back button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setBackground(new Color(45, 45, 60));
        bottomPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 40, 20));

        // Create a close button similar to the back button in status view
        JButton closeButton = new JButton("Close");
        closeButton.setFont(new Font("Times New Roman", Font.BOLD, 20));
        closeButton.setBackground(new Color(70, 130, 180));
        closeButton.setForeground(Color.WHITE);
        closeButton.setFocusPainted(false);
        closeButton.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(50, 110, 160), 2),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)
        ));
        closeButton.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effect similar to other buttons
        closeButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                closeButton.setBackground(new Color(60, 120, 170));
            }
            @Override
            public void mouseExited(MouseEvent e) {
                closeButton.setBackground(new Color(70, 130, 180));
            }
        });

        closeButton.addActionListener(e -> dialog.dispose());
        bottomPanel.add(closeButton);

        dialog.add(bottomPanel, BorderLayout.SOUTH);

        dialog.setVisible(true);
    }

    // Helper method to get status order for sorting
    private int getStatusOrder(String status) {
        switch (status) {
            case "Pending": return 1;    // Highest priority
            case "In Progress": return 2; // Medium priority
            case "Completed": return 3;   // Lowest priority
            default: return 4;
        }
    }

    // Helper method to get time status with remaining time
    private String getTimeStatusWithRemaining(Task task) {
        Date now = new Date();

        // If task is completed
        if (task.status.equals("Completed")) {
            return "✅ Done";
        }

        // If task has no time set
        if (task.startTime == null || task.endTime == null) {
            return "No time set";
        }

        // If overdue
        if (task.endTime.before(now)) {
            long overdueMillis = now.getTime() - task.endTime.getTime();
            long overdueHours = overdueMillis / (1000 * 60 * 60);
            long overdueMinutes = (overdueMillis % (1000 * 60 * 60)) / (1000 * 60);

            if (overdueHours > 0) {
                return "Overdue " + overdueHours + "h";
            } else {
                return "Overdue " + overdueMinutes + "m";
            }
        }

        // If active (between start and end time)
        if (task.startTime.before(now) && task.endTime.after(now)) {
            long remainingMillis = task.endTime.getTime() - now.getTime();
            long remainingHours = remainingMillis / (1000 * 60 * 60);
            long remainingMinutes = (remainingMillis % (1000 * 60 * 60)) / (1000 * 60);

            if (remainingHours > 0) {
                return remainingHours + "h left";
            } else {
                return remainingMinutes + "m left";
            }
        }

        // If upcoming (start time in future)
        if (task.startTime.after(now)) {
            long untilStartMillis = task.startTime.getTime() - now.getTime();
            long untilStartHours = untilStartMillis / (1000 * 60 * 60);

            if (untilStartHours < 24) {
                return "Starts in " + untilStartHours + "h";
            } else {
                return "Tomorrow";
            }
        }

        return "No time set";
    }
    // Helper method to create legend panel
//


    private void showUpdateStatusDialog() {
        // Same as original
        List<Task> tasks = taskBST.inorderTraversal();
        if (tasks.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks available to update!");
            return;
        }

        JDialog dialog = new JDialog(this, "Update Task Status", true);
        dialog.setSize(500, 400);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new BorderLayout(10, 10));

        JPanel selectionPanel = new JPanel(new BorderLayout());
        selectionPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        JLabel selectLabel = new JLabel("Select Task:");
        selectLabel.setFont(new Font("Arial", Font.BOLD, 14));
        String[] taskOptions = tasks.stream()
                .map(t -> "ID: " + t.id + " - " + t.title + " (Current: " + t.status + ")")
                .toArray(String[]::new);
        JComboBox<String> taskComboBox = new JComboBox<>(taskOptions);
        selectionPanel.add(selectLabel, BorderLayout.NORTH);
        selectionPanel.add(taskComboBox, BorderLayout.CENTER);

        JPanel statusPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        statusPanel.setBorder(BorderFactory.createTitledBorder("Select New Status"));
        ButtonGroup statusGroup = new ButtonGroup();
        JRadioButton pendingButton = new JRadioButton("Pending");
        JRadioButton inProgressButton = new JRadioButton("In Progress");
        JRadioButton completedButton = new JRadioButton("Completed");
        pendingButton.setBackground(Color.WHITE);
        inProgressButton.setBackground(Color.WHITE);
        completedButton.setBackground(Color.WHITE);
        statusGroup.add(pendingButton);
        statusGroup.add(inProgressButton);
        statusGroup.add(completedButton);

        taskComboBox.addActionListener(e -> {
            int selectedIndex = taskComboBox.getSelectedIndex();
            if (selectedIndex >= 0) {
                Task selectedTask = tasks.get(selectedIndex);
                switch (selectedTask.status) {
                    case "Pending": pendingButton.setSelected(true); break;
                    case "In Progress": inProgressButton.setSelected(true); break;
                    case "Completed": completedButton.setSelected(true); break;
                }
            }
        });

        if (taskComboBox.getItemCount() > 0) { taskComboBox.setSelectedIndex(0); }
        statusPanel.add(pendingButton);
        statusPanel.add(inProgressButton);
        statusPanel.add(completedButton);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton updateButton = new JButton("Update Status");
        updateButton.setBackground(new Color(76, 175, 80));
        updateButton.setForeground(Color.WHITE);
        updateButton.setFocusPainted(false);
        JButton cancelButton = new JButton("Cancel");
        cancelButton.setBackground(new Color(244, 67, 54));
        cancelButton.setForeground(Color.WHITE);
        cancelButton.setFocusPainted(false);

        updateButton.addActionListener(e -> {
            int selectedIndex = taskComboBox.getSelectedIndex();
            if (selectedIndex < 0) {
                JOptionPane.showMessageDialog(dialog, "Please select a task!");
                return;
            }

            Task selectedTask = tasks.get(selectedIndex);
            String oldStatus = selectedTask.status;
            String newStatus = "";
            if (pendingButton.isSelected()) { newStatus = "Pending"; }
            else if (inProgressButton.isSelected()) { newStatus = "In Progress"; }
            else if (completedButton.isSelected()) { newStatus = "Completed"; }
            else {
                JOptionPane.showMessageDialog(dialog, "Please select a status!");
                return;
            }

            if (oldStatus.equals(newStatus)) {
                JOptionPane.showMessageDialog(dialog, "Task status is already: " + newStatus);
                return;
            }

            selectedTask.status = newStatus;
            priorityQueue.remove(selectedTask);
            priorityQueue.add(selectedTask);
            activityLog.enqueue("Task status updated: " + selectedTask.title + " (" + oldStatus + " → " + newStatus + ")");
            JOptionPane.showMessageDialog(dialog,
                    "Task status updated successfully!\n" +
                            "Task: " + selectedTask.title + "\n" +
                            "New Status: " + newStatus);
            dialog.dispose();
        });

        cancelButton.addActionListener(e -> dialog.dispose());
        buttonPanel.add(updateButton);
        buttonPanel.add(cancelButton);

        JPanel contentPanel = new JPanel(new BorderLayout(10, 10));
        contentPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        contentPanel.add(selectionPanel, BorderLayout.NORTH);
        contentPanel.add(statusPanel, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);
        dialog.add(contentPanel, BorderLayout.CENTER);
        dialog.setVisible(true);
    }

    private void showStatusDialog() {
        // Same as original
        List<Task> tasks = taskBST.inorderTraversal();
        if (tasks.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks available!");
            return;
        }

        int pending = 0, inProgress = 0, completed = 0;
        int high = 0, medium = 0, low = 0;
        int overdue = 0, active = 0, upcoming = 0;

        for (Task task : tasks) {
            switch (task.status) {
                case "Pending": pending++; break;
                case "In Progress": inProgress++; break;
                case "Completed": completed++; break;
            }
            switch (task.priority) {
                case 3: high++; break;
                case 2: medium++; break;
                case 1: low++; break;
            }
            if (task.endTime != null && task.endTime.before(new Date()) && !task.status.equals("Completed")) {
                overdue++;
            } else if (task.startTime != null && task.endTime != null &&
                    task.startTime.before(new Date()) && task.endTime.after(new Date())) {
                active++;
            } else if (task.startTime != null && task.startTime.after(new Date())) {
                upcoming++;
            }
        }

        String statusMsg = String.format(
                "📊 Task Statistics\n\n" +
                        "Total Tasks: %d\n\n" +
                        "Status Breakdown:\n" +
                        " • Pending: %d\n" +
                        " • In Progress: %d\n" +
                        " • Completed: %d\n\n" +
                        "Priority Breakdown:\n" +
                        " • High: %d\n" +
                        " • Medium: %d\n" +
                        " • Low: %d\n\n" +
                        "Time Status:\n" +
                        " • Overdue: %d\n" +
                        " • Active: %d\n" +
                        " • Upcoming: %d",
                tasks.size(), pending, inProgress, completed, high, medium, low, overdue, active, upcoming
        );

        JOptionPane.showMessageDialog(this, statusMsg, "Status Overview", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showActivityLog() {
        // Same as original
        List<String> activities = activityLog.getActivities();
        if (activities.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No recent activities!");
            return;
        }

        StringBuilder log = new StringBuilder("📜 Recent Activities:\n\n");
        for (int i = activities.size() - 1; i >= 0; i--) {
            log.append((activities.size() - i)).append(". ").append(activities.get(i)).append("\n");
        }

        JTextArea textArea = new JTextArea(log.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 300));
        JOptionPane.showMessageDialog(this, scrollPane, "Activity Log", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAboutDialog() {
        // Same as original
        String aboutText =
                "📋 Task Scheduler - DSA Project\n\n" +
                        "Version: 1.4\n\n" +
                        "Data Structures Implemented:\n" +
                        "• Priority Queue - High priority tasks first\n" +
                        "• Binary Search Tree - Task organization by ID\n" +
                        "• Circular Queue - Activity logging (last 10)\n" +
                        "• HashMap - User authentication system\n\n" +
                        "Features:\n" +
                        "✓ Secure login authentication\n" +
                        "✓ Priority-based task scheduling\n" +
                        "✓ Task management (Insert, Delete, View)\n" +
                        "✓ Real-time status tracking\n" +
                        "✓ Activity history logging\n" +
                        "✓ File persistence - Data saved automatically\n" +
                        "✓ Enhanced calendar date picker\n" +
                        "✓ Simplified time picker with AM/PM\n" +
                        "✓ Task status management (Pending/In Progress/Completed)\n" +
                        "✓ Window maximization/minimization\n" +
                        "✓ 12-hour time format with AM/PM\n\n" +
                        "NEW in Version 1.4:\n" +
                        "• Simplified time selection with single-click\n" +
                        "• Task status update functionality\n" +
                        "• Improved user interface\n\n" +
                        "Developed as a DSA course project\n" +
                        "© 2024 Task Scheduler Team";

        JOptionPane.showMessageDialog(this, aboutText, "About Task Scheduler", JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== MAIN METHOD ====================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            TaskScheduler app = new TaskScheduler();
            app.setVisible(true);
        });
    }
}