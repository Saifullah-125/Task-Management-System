import java.util.HashMap;
import java.util.Map;

// HashMap for user authentication
class LoginPage {
    private Map<String, String> users;
    
    public LoginPage() {
        users = new HashMap<>();
        // Pre-registered users
        users.put("admin", "admin123");
        users.put("user1", "pass123");
        users.put("demo", "demo");
    }
    
    public boolean authenticate(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }
    
    public boolean registerUser(String username, String password) {
        if (users.containsKey(username)) {
            return false;
        }
        users.put(username, password);
        return true;
    }
}