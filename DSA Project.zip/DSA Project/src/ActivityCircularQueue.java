import java.util.ArrayList;
import java.util.List;

// Circular Queue for recent activities
class ActivityCircularQueue {
    private String[] queue;
    private int front, rear, size, capacity;
    
    public ActivityCircularQueue(int capacity) {
        this.capacity = capacity;
        queue = new String[capacity];
        front = rear = -1;
        size = 0;
    }
    
    public void enqueue(String activity) {
        if (size == capacity) {
            dequeue();
        }
        
        if (front == -1) {
            front = 0;
        }
        rear = (rear + 1) % capacity;
        queue[rear] = activity;
        size++;
    }
    
    private void dequeue() {
        if (size == 0) return;
        front = (front + 1) % capacity;
        size--;
        if (size == 0) {
            front = rear = -1;
        }
    }
    
    public List<String> getActivities() {
        List<String> activities = new ArrayList<>();
        if (size == 0) return activities;
        
        int i = front;
        for (int count = 0; count < size; count++) {
            activities.add(queue[i]);
            i = (i + 1) % capacity;
        }
        return activities;
    }
}