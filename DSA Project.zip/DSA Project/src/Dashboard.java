import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
// ==================== MAIN APPLICATION ====================

public class Dashboard extends JFrame {
    private LoginPage authSystem;
    private TaskPriorityQueue priorityQueue;
    private TaskBST taskBST;
    private ActivityCircularQueue activityLog;
    private String currentUser;
    private int taskIdCounter = 1;

    private CardLayout cardLayout;
    private JPanel mainPanel;

    public Dashboard() {
        authSystem = new LoginPage();
        priorityQueue = new TaskPriorityQueue();
        taskBST = new TaskBST();
        activityLog = new ActivityCircularQueue(10);

        setTitle("Task Scheduler - DSA Project");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(createLoginPanel(), "LOGIN");
        mainPanel.add(createDashboardPanel(), "DASHBOARD");

        add(mainPanel);
        cardLayout.show(mainPanel, "LOGIN");
    }

    // ==================== LOGIN PANEL ====================

    private JPanel createLoginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(240, 240, 240));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel titleLabel = new JLabel("🔒 Task Scheduler Login");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(titleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        panel.add(new JLabel("Username:"), gbc);

        JTextField usernameField = new JTextField(20);
        gbc.gridx = 1;
        panel.add(usernameField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(new JLabel("Password:"), gbc);

        JPasswordField passwordField = new JPasswordField(20);
        gbc.gridx = 1;
        panel.add(passwordField, gbc);

        JButton loginButton = new JButton("Login");
        loginButton.setBackground(new Color(76, 175, 80));
        loginButton.setForeground(Color.WHITE);
        loginButton.setFocusPainted(false);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        panel.add(loginButton, gbc);

        JLabel infoLabel = new JLabel("<html><i>Demo credentials: username='demo', password='demo'</i></html>");
        infoLabel.setForeground(Color.GRAY);
        gbc.gridy = 4;
        panel.add(infoLabel, gbc);

        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            if (authSystem.authenticate(username, password)) {
                currentUser = username;
                activityLog.enqueue("User '" + username + "' logged in");
                JOptionPane.showMessageDialog(this, "Welcome, " + username + "!");
                cardLayout.show(mainPanel, "DASHBOARD");
            } else {
                JOptionPane.showMessageDialog(this, "Invalid credentials!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        return panel;
    }

    // ==================== DASHBOARD PANEL ====================

    private JPanel createDashboardPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(33, 150, 243));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));

        JLabel headerLabel = new JLabel("📋 Task Scheduler Dashboard");
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerLabel.setForeground(Color.WHITE);
        headerPanel.add(headerLabel, BorderLayout.WEST);

        JButton logoutButton = new JButton("Logout");
        logoutButton.setBackground(new Color(244, 67, 54));
        logoutButton.setForeground(Color.WHITE);
        logoutButton.setFocusPainted(false);
        logoutButton.addActionListener(e -> {
            activityLog.enqueue("User '" + currentUser + "' logged out");
            currentUser = null;
            cardLayout.show(mainPanel, "LOGIN");
        });
        headerPanel.add(logoutButton, BorderLayout.EAST);

        panel.add(headerPanel, BorderLayout.NORTH);

        // Button Panel
        JPanel buttonPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(Color.WHITE);

        JButton insertButton = createStyledButton("➕ Insert Task", new Color(76, 175, 80));
        JButton deleteButton = createStyledButton("🗑️ Delete Task", new Color(244, 67, 54));
        JButton todoButton = createStyledButton("📝 To-Do List", new Color(33, 150, 243));
        JButton statusButton = createStyledButton("📊 Status", new Color(255, 152, 0));
        JButton activityButton = createStyledButton("📜 Activity Log", new Color(156, 39, 176));
        JButton aboutButton = createStyledButton("ℹ️ About Us", new Color(96, 125, 139));

        buttonPanel.add(insertButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(todoButton);
        buttonPanel.add(statusButton);
        buttonPanel.add(activityButton);
        buttonPanel.add(aboutButton);

        panel.add(buttonPanel, BorderLayout.CENTER);

        // Button Actions
        insertButton.addActionListener(e -> showInsertTaskDialog());
        deleteButton.addActionListener(e -> showDeleteTaskDialog());
        todoButton.addActionListener(e -> showToDoList());
        statusButton.addActionListener(e -> showStatusDialog());
        activityButton.addActionListener(e -> showActivityLog());
        aboutButton.addActionListener(e -> showAboutDialog());

        return panel;
    }

    private JButton createStyledButton(String text, Color bgColor) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }

    // ==================== INSERT TASK ====================

    private void showInsertTaskDialog() {
        JDialog dialog = new JDialog(this, "Insert New Task", true);
        dialog.setSize(400, 350);
        dialog.setLocationRelativeTo(this);
        dialog.setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 10, 5, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JTextField titleField = new JTextField(20);
        JTextArea descArea = new JTextArea(4, 20);
        descArea.setLineWrap(true);
        JScrollPane descScroll = new JScrollPane(descArea);

        String[] priorities = {"Low", "Medium", "High"};
        JComboBox<String> priorityBox = new JComboBox<>(priorities);

        gbc.gridx = 0; gbc.gridy = 0;
        dialog.add(new JLabel("Task Title:"), gbc);
        gbc.gridx = 1;
        dialog.add(titleField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        dialog.add(new JLabel("Description:"), gbc);
        gbc.gridx = 1;
        dialog.add(descScroll, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        dialog.add(new JLabel("Priority:"), gbc);
        gbc.gridx = 1;
        dialog.add(priorityBox, gbc);

        JButton addButton = new JButton("Add Task");
        addButton.setBackground(new Color(76, 175, 80));
        addButton.setForeground(Color.WHITE);
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        dialog.add(addButton, gbc);

        addButton.addActionListener(e -> {
            String title = titleField.getText().trim();
            String desc = descArea.getText().trim();
            int priority = priorityBox.getSelectedIndex() + 1;

            if (title.isEmpty()) {
                JOptionPane.showMessageDialog(dialog, "Please enter task title!");
                return;
            }

            Task task = new Task(taskIdCounter++, title, desc, priority);
            priorityQueue.add(task);
            taskBST.insert(task);
            activityLog.enqueue("Task added: " + title + " (Priority: " + task.getPriorityString() + ")");

            JOptionPane.showMessageDialog(dialog, "Task added successfully!");
            dialog.dispose();
        });

        dialog.setVisible(true);
    }

    // ==================== DELETE TASK ====================

    private void showDeleteTaskDialog() {
        List<Task> tasks = taskBST.inorderTraversal();
        if (tasks.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks to delete!");
            return;
        }

        String[] taskOptions = tasks.stream()
            .map(t -> "ID: " + t.id + " - " + t.title)
            .toArray(String[]::new);

        String selected = (String) JOptionPane.showInputDialog(this,
            "Select task to delete:",
            "Delete Task",
            JOptionPane.QUESTION_MESSAGE,
            null,
            taskOptions,
            taskOptions[0]);

        if (selected != null) {
            int id = Integer.parseInt(selected.split(" - ")[0].replace("ID: ", ""));
            Task task = taskBST.search(id);

            if (task != null) {
                taskBST.delete(id);
                priorityQueue.remove(task);
                activityLog.enqueue("Task deleted: " + task.title);
                JOptionPane.showMessageDialog(this, "Task deleted successfully!");
            }
        }
    }

    // ==================== TO-DO LIST ====================

    private void showToDoList() {
        List<Task> tasks = priorityQueue.getAllTasks();

        if (tasks.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks in queue!");
            return;
        }

        JDialog dialog = new JDialog(this, "To-Do List (Priority Order)", true);
        dialog.setSize(700, 400);
        dialog.setLocationRelativeTo(this);

        String[] columns = {"ID", "Title", "Priority", "Status", "Description"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        for (Task task : tasks) {
            model.addRow(new Object[]{
                task.id,
                task.title,
                task.getPriorityString(),
                task.status,
                task.description
            });
        }

        JTable table = new JTable(model);
        table.setRowHeight(25);
        JScrollPane scrollPane = new JScrollPane(table);
        dialog.add(scrollPane);

        dialog.setVisible(true);
    }

    // ==================== STATUS ====================

    private void showStatusDialog() {
        List<Task> tasks = taskBST.inorderTraversal();

        if (tasks.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tasks available!");
            return;
        }

        int pending = 0, inProgress = 0, completed = 0;
        int high = 0, medium = 0, low = 0;

        for (Task task : tasks) {
            switch (task.status) {
                case "Pending": pending++; break;
                case "In Progress": inProgress++; break;
                case "Completed": completed++; break;
            }

            switch (task.priority) {
                case 3: high++; break;
                case 2: medium++; break;
                case 1: low++; break;
            }
        }

        String statusMsg = String.format(
            "📊 Task Statistics\n\n" +
            "Total Tasks: %d\n\n" +
            "Status Breakdown:\n" +
            "  • Pending: %d\n" +
            "  • In Progress: %d\n" +
            "  • Completed: %d\n\n" +
            "Priority Breakdown:\n" +
            "  • High: %d\n" +
            "  • Medium: %d\n" +
            "  • Low: %d",
            tasks.size(), pending, inProgress, completed, high, medium, low
        );

        JOptionPane.showMessageDialog(this, statusMsg, "Status Overview", JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== ACTIVITY LOG ====================

    private void showActivityLog() {
        List<String> activities = activityLog.getActivities();

        if (activities.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No recent activities!");
            return;
        }

        StringBuilder log = new StringBuilder("📜 Recent Activities:\n\n");
        for (int i = activities.size() - 1; i >= 0; i--) {
            log.append((activities.size() - i)).append(". ").append(activities.get(i)).append("\n");
        }

        JTextArea textArea = new JTextArea(log.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 300));

        JOptionPane.showMessageDialog(this, scrollPane, "Activity Log", JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== ABOUT ====================

    private void showAboutDialog() {
        String aboutText =
            "📋 Task Scheduler - DSA Project\n\n" +
            "Version: 1.0\n\n" +
            "Data Structures Implemented:\n" +
            "• Priority Queue - High priority tasks first\n" +
            "• Binary Search Tree - Task organization by ID\n" +
            "• Circular Queue - Activity logging (last 10)\n" +
            "• HashMap - User authentication system\n\n" +
            "Features:\n" +
            "✓ Secure login authentication\n" +
            "✓ Priority-based task scheduling\n" +
            "✓ Task management (Insert, Delete, View)\n" +
            "✓ Real-time status tracking\n" +
            "✓ Activity history logging\n\n" +
            "Developed as a DSA course project\n" +
            "© 2024 Task Scheduler Team";

        JOptionPane.showMessageDialog(this, aboutText, "About Task Scheduler", JOptionPane.INFORMATION_MESSAGE);
    }

    // ==================== MAIN METHOD ====================

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Dashboard app = new Dashboard();
            app.setVisible(true);
        });
    }
}