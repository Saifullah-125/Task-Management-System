// ==================== TASK CLASS ====================

import java.util.Date;

class Task {
    int id;
    String title;
    String description;
    int priority; // 1=Low, 2=Medium, 3=High
    String status; // Pending, In Progress, Completed
    Date addedTime;
    
    public Task(int id, String title, String description, int priority) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.priority = priority;
        this.status = "Pending";
        this.addedTime = new Date();
    }
    
    public String getPriorityString() {
        switch(priority) {
            case 3: return "High";
            case 2: return "Medium";
            default: return "Low";
        }
    }
}