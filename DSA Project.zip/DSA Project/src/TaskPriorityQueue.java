// ==================== DATA STRUCTURES ====================

import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;

// Priority Queue for high-priority tasks
class TaskPriorityQueue {
    private PriorityQueue<Task> pQueue;
    
    public TaskPriorityQueue() {
        pQueue = new PriorityQueue<>((t1, t2) -> {
            int priorityCompare = Integer.compare(t2.priority, t1.priority);
            if (priorityCompare != 0) return priorityCompare;
            return t1.addedTime.compareTo(t2.addedTime);
        });
    }
    
    public void add(Task task) {
        pQueue.offer(task);
    }
    
    public Task poll() {
        return pQueue.poll();
    }
    
    public boolean isEmpty() {
        return pQueue.isEmpty();
    }
    
    public List<Task> getAllTasks() {
        return new ArrayList<>(pQueue);
    }
    
    public void remove(Task task) {
        pQueue.remove(task);
    }
}
